# 🚀 POWER BI DASHBOARD - STEP-BY-STEP IMPLEMENTATION GUIDE

**Project:** Bluestock Mutual Fund Analytics  
**Dashboard:** bluestock_mf_dashboard.pbix  
**Duration:** 7-8 hours  
**Level:** Intermediate  

---

## PHASE 1: SETUP & DATA IMPORT (1-2 hours)

### **Step 1: Install Power BI Desktop**

```
1. Download from: powerbi.microsoft.com/download
2. Install Power BI Desktop (free)
3. Launch application
4. Sign in with Microsoft account (or skip)
```

### **Step 2: Create New Project**

```
1. File → New
2. Save As: bluestock_mf_dashboard.pbix
3. Location: Your project folder
4. Click Save
```

### **Step 3: Import Data (From CSV Files)**

#### **Import Method 1: Using Get Data (Recommended)**

```
Step A: Home → Get data → More → CSV
├─ Navigate to: data/raw/01_fund_master.csv
├─ Click: Load
├─ Wait for data preview
└─ Verify columns visible

Step B: Repeat for all 10 CSV files:
├─ 01_fund_master.csv
├─ 02_nav_history.csv
├─ 03_aum_by_fund_house.csv
├─ 04_monthly_sip_inflows.csv
├─ 05_category_inflows.csv
├─ 06_industry_folio_count.csv
├─ 07_scheme_performance.csv
├─ 08_investor_transactions.csv
├─ 09_portfolio_holdings.csv
└─ 10_benchmark_indices.csv
```

#### **Import Method 2: Using SQLite Database (If Available)**

```
1. Home → Get data → More → OLE DB
2. Connection string: Data Source=bluestock_mf.db
3. Click OK
4. Select tables to import
5. Click Load
```

### **Step 4: Transform Data (Power Query)**

```
For each imported table:

1. Home → Transform data (opens Power Query)
2. For date columns:
   ├─ Select column
   ├─ Change type → Date
   └─ Done
3. For numeric columns:
   ├─ Select column
   ├─ Change type → Decimal/Whole Number
   └─ Done
4. Remove duplicates if any
5. Close & Apply
```

### **Step 5: Create Relationships**

```
1. Go to: Model view (top right)
2. You should see all imported tables

Create Relationships:

Relationship 1: dim_fund ↔ fact_nav
├─ Drag: dim_fund.amfi_code → fact_nav.amfi_code
├─ Cardinality: One to Many (1:*)
└─ Direction: Single

Relationship 2: dim_fund ↔ fact_performance
├─ Drag: dim_fund.amfi_code → fact_performance.amfi_code
├─ Cardinality: One to Many (1:*)
└─ Direction: Single

Relationship 3: fact_nav ↔ fact_indices
├─ Drag: fact_nav.date → fact_indices.date
├─ Cardinality: Many to Many (*)
└─ Direction: Both

[Continue for remaining relationships...]

Verify:
├─ All tables connected
├─ No orphaned tables
└─ Relationships are correct direction
```

---

## PHASE 2: CREATE PAGES & VISUALIZATIONS (3-4 hours)

### **PAGE 1: INDUSTRY OVERVIEW**

#### **Step 1: Create Page**
```
1. Right-click on page tab → New page
2. Name it: "Industry Overview"
3. Set page size: 16:9 (standard)
```

#### **Step 2: Add KPI Cards (Top Section)**

```
KPI Card 1: Total AUM

1. Insert → Card
2. Fields → Select: aum_by_fund_house[aum_crore]
   (Drag to Value field)
3. Format:
   ├─ Title: "Total AUM"
   ├─ Display units: Millions
   ├─ Format: Currency
   └─ Decimal places: 0
4. Value should show: ₹81,00,000 Cr (or similar)
5. Position: Top-left

KPI Card 2: SIP Inflows

1. Insert → Card
2. Fields → monthly_sip_inflows[sip_inflow_crore]
   (Select most recent month)
3. Format similar to above
4. Value should show: ₹31,002 Cr
5. Position: Top-center-left

KPI Card 3: Total Folios

1. Insert → Card
2. Fields → industry_folio_count[total_folios]
3. Value should show: 26.12 Cr
4. Position: Top-center-right

KPI Card 4: Schemes Listed

1. Insert → Card
2. Fields → fund_master (Count)
3. Value should show: 1,908 schemes
4. Position: Top-right
```

#### **Step 3: Add Line Chart (AUM Trend)**

```
1. Insert → Line chart
2. Axes:
   ├─ X-axis: aum_by_fund_house[date] (Month)
   └─ Y-axis: aum_by_fund_house[aum_crore]
3. Series: Total AUM
4. Format:
   ├─ Color: Bluestock blue (#0078D4)
   ├─ Line style: Smooth
   ├─ Show data points: Yes
   └─ Show legend: No
5. Position: Left side, middle
6. Size: Wide, medium height
```

#### **Step 4: Add Bar Chart (AUM by Fund House)**

```
1. Insert → Bar chart (Horizontal)
2. Axes:
   ├─ Axis: aum_by_fund_house[fund_house]
   └─ Value: aum_by_fund_house[aum_crore]
3. Sort: By value, descending
4. Format:
   ├─ Color: Gradient blue
   ├─ Show data labels: Yes
   └─ Show legend: No
5. Display: Top 10 fund houses
6. Position: Right side, middle
7. Size: Medium width, medium height
```

#### **Step 5: Add Pie Chart (Category Distribution)**

```
1. Insert → Pie chart
2. Legend: category_inflows[category]
3. Values: category_inflows[net_inflow]
4. Format:
   ├─ Show percentages: Yes
   ├─ Show legend: Yes
   └─ Color: Category colors
5. Position: Right side, bottom
```

### **PAGE 2: FUND PERFORMANCE**

#### **Step 1: Create Page & Add Slicers**

```
1. Right-click → New page
2. Name: "Fund Performance"
3. Insert slicers at top:

Slicer 1: Fund House
├─ Insert → Slicer
├─ Field: fund_master[fund_house]
├─ Style: Dropdown
└─ Position: Top-left

Slicer 2: Category
├─ Insert → Slicer
├─ Field: fund_master[category]
├─ Style: Dropdown
└─ Position: Top-center

Slicer 3: Plan
├─ Insert → Slicer
├─ Field: fund_master[plan]
├─ Style: Dropdown
└─ Position: Top-right
```

#### **Step 2: Add Scatter Plot (Risk vs Return)**

```
1. Insert → Scatter chart
2. X-axis: scheme_performance[std_dev_ann_pct]
3. Y-axis: scheme_performance[return_3yr_pct]
4. Legend: fund_master[category]
5. Bubble size: aum_by_fund_house[aum_crore]
6. Format:
   ├─ Title: "Risk vs Return (Bubble = AUM)"
   ├─ Show legend: Yes
   ├─ Show all axis labels: Yes
   └─ Color: By category
7. Position: Left side, large
```

#### **Step 3: Add Table (Fund Scorecard)**

```
1. Insert → Table
2. Columns:
   ├─ fund_master[scheme_name]
   ├─ scheme_performance[return_1yr_pct]
   ├─ scheme_performance[return_3yr_pct]
   ├─ scheme_performance[return_5yr_pct]
   ├─ scheme_performance[sharpe_ratio]
   ├─ scheme_performance[alpha]
   ├─ fund_master[risk_category]
   └─ [Calculated] Overall Score
3. Format:
   ├─ Grid style: Modern
   ├─ Column headers: Bold
   ├─ Conditional formatting: Score column (Green>80, Yellow>60)
   ├─ Sorting: By score, descending
   └─ Show: Top 20 funds
4. Position: Right side
5. Size: Medium-wide, tall

Enable Drill-through:
└─ Right-click table → Enable drill-through
```

#### **Step 4: Add Line Chart (NAV Trend)**

```
1. Insert → Line chart
2. X-axis: nav_history[date]
3. Y-axis: nav_history[nav]
4. Legend: Select specific fund (via slicer)
5. Series:
   ├─ Series 1: Fund NAV (bold, blue)
   └─ Series 2: Benchmark index (thin, orange)
6. Format:
   ├─ Show data points: No
   ├─ Show legend: Yes
   └─ Smooth line: Yes
7. Position: Bottom, wide
8. Time period: Last 3 years
```

### **PAGE 3: INVESTOR ANALYTICS**

#### **Step 1: Add Slicers**

```
Slicer 1: State
├─ Field: investor_transactions[state]
├─ Style: Dropdown
└─ Position: Top-left

Slicer 2: Age Group
├─ Field: investor_transactions[age_group]
├─ Style: Button group
└─ Position: Top-center

Slicer 3: City Tier
├─ Field: investor_transactions[city_tier]
├─ Style: Button group
└─ Position: Top-right
```

#### **Step 2: Add Bar Chart (Geographic Distribution)**

```
1. Insert → Horizontal bar chart
2. Axis: investor_transactions[state]
3. Value: investor_transactions[amount_inr] (Sum)
4. Sort: By value, descending
5. Format:
   ├─ Show top 10 states
   ├─ Data labels: Yes
   └─ Color: Gradient blue
6. Position: Left side
```

#### **Step 3: Add Donut Chart (Transaction Type)**

```
1. Insert → Donut chart
2. Legend: investor_transactions[transaction_type]
3. Values: investor_transactions[transaction_id] (Count)
4. Format:
   ├─ Show percentages: Yes
   ├─ Show legend: Yes
   └─ Color: Different for each type
5. Position: Right-top
```

#### **Step 4: Add Bar Chart (Age Group vs Avg SIP)**

```
1. Insert → Bar chart (Vertical)
2. X-axis: investor_transactions[age_group]
3. Y-axis: investor_transactions[amount_inr] (Average)
4. Sort: By age group
5. Format:
   ├─ Data labels: Yes
   ├─ Color: Single color or gradient
   └─ Show trend line: Optional
6. Position: Right-center
```

#### **Step 5: Add Pie Chart (T30 vs B30)**

```
1. Insert → Pie chart
2. Legend: investor_transactions[city_tier]
3. Values: investor_transactions[amount_inr] (Sum)
4. Format:
   ├─ Show percentages: Yes
   └─ Color: Distinct colors
5. Position: Right-bottom
```

#### **Step 6: Add Line Chart (Monthly Transaction Volume)**

```
1. Insert → Line chart
2. X-axis: investor_transactions[transaction_date] (Month)
3. Y-axis: investor_transactions[transaction_id] (Count)
4. Format:
   ├─ Smooth line: Yes
   ├─ Show data points: Yes
   └─ Color: Bluestock blue
5. Position: Bottom, wide
```

### **PAGE 4: SIP & MARKET TRENDS**

#### **Step 1: Add Dual-Axis Chart**

```
1. Insert → Combo chart
2. Column Series: monthly_sip_inflows[sip_inflow_crore]
3. Line Series: benchmark_indices[nifty_50_index]
4. X-axis: Date (Month)
5. Format:
   ├─ Left Y-axis: SIP Inflow (Rs. Crore)
   ├─ Right Y-axis: Index points
   ├─ Column color: Bluestock blue
   ├─ Line color: Orange
   └─ Show legend: Yes
6. Position: Top, wide
7. Display: 2022-2025 data
```

#### **Step 2: Add Heatmap (Category Inflows)**

```
1. Insert → Table with conditional formatting
2. Rows: Category_inflows[month]
3. Columns: Category_inflows[category]
4. Values: Category_inflows[net_inflow]
5. Apply conditional formatting:
   ├─ Color scale
   ├─ Minimum: Red (low inflows)
   ├─ Middle: Yellow
   └─ Maximum: Green (high inflows)
6. Position: Middle, wide
```

#### **Step 3: Add Bar Chart (Top 5 Categories)**

```
1. Insert → Horizontal bar chart
2. Axis: category_inflows[category]
3. Value: category_inflows[net_inflow]
4. Sort: Descending
5. Format:
   ├─ Show top 5
   ├─ Data labels: Yes (values + %)
   ├─ Color: Gradient
   └─ Show legend: No
6. Position: Bottom
```

---

## PHASE 3: FORMATTING & INTERACTIVITY (1-2 hours)

### **Step 1: Apply Branding**

```
For each page:

1. Insert → Image
   └─ Add Bluestock logo (top-left corner)

2. Format → Page → Page size
   └─ Set to: 16:9 (standard)

3. Format → Background
   └─ Light blue color (#E7F3FB)

4. Title text:
   ├─ Font: Segoe UI Bold
   ├─ Size: 24px
   ├─ Color: Bluestock blue (#0078D4)
   └─ Alignment: Left
```

### **Step 2: Add Drill-Through Pages**

```
Create Fund Detail Page:
1. Right-click → New page
2. Name: "Fund Detail"
3. Add page-level filter:
   ├─ Field: fund_master[amfi_code]
   └─ Create drill-through parameter

Add Visuals:
├─ Fund name and metrics
├─ Complete financial ratios
├─ 5-year NAV chart
├─ Risk metrics
└─ Historical performance

Enable drill-through:
└─ Right-click visuals on Page 2
    └─ Enable drill-through for this page
```

### **Step 3: Add Tooltips**

```
For each visualization:

1. Select visualization
2. Format → Tooltips
3. Add fields to show on hover:
   ├─ Key metrics
   ├─ Percentages
   ├─ Trend information
   └─ Additional context

Example for Scatter Plot:
├─ Fund name
├─ Return (%)
├─ Risk (%)
├─ Sharpe ratio
├─ AUM
└─ Category
```

### **Step 4: Set Filter Interactions**

```
1. Select slicer
2. Format → Edit interactions
3. For each visualization:
   ├─ Decide: Filter / Highlight / None
   ├─ Usually: Filter for slicers
   └─ Apply

Example:
- Fund House slicer → Filters all charts
- Category slicer → Filters all charts
- State slicer → Filters Page 3 only
- Age group slicer → Filters Page 3 only
```

---

## PHASE 4: EXPORT & FINALIZATION (30 minutes)

### **Step 1: Save Dashboard**

```
1. File → Save
2. File name: bluestock_mf_dashboard.pbix
3. Location: Project root folder
4. Verify file created successfully
```

### **Step 2: Export to PDF**

```
1. File → Export as PDF
2. Select: Pages to export
   ├─ Industry Overview (Page 1)
   ├─ Fund Performance (Page 2)
   ├─ Investor Analytics (Page 3)
   └─ SIP Trends (Page 4)
3. File name: Dashboard.pdf
4. Location: exports/ folder
5. Click Export
```

### **Step 3: Export Page Screenshots (PNG)**

```
For each page:

1. Go to page (e.g., Industry Overview)
2. Fit entire page in view
3. Print Screen (or Right-click → Export as image)
4. Save as:
   ├─ Page1_Industry_Overview.png
   ├─ Page2_Fund_Performance.png
   ├─ Page3_Investor_Analytics.png
   └─ Page4_SIP_Trends.png
5. Location: exports/ folder
6. Resolution: 1920x1080 or higher
```

### **Step 4: Verify Deliverables**

```
✅ Checklist:

Files Created:
☐ bluestock_mf_dashboard.pbix (main file)
☐ Dashboard.pdf (4 pages)
☐ Page1_Industry_Overview.png
☐ Page2_Fund_Performance.png
☐ Page3_Investor_Analytics.png
☐ Page4_SIP_Trends.png

Functionality:
☐ All KPI cards display correctly
☐ All charts load and display data
☐ All slicers filter properly
☐ Drill-through works on Fund Performance
☐ Tooltips show on hover
☐ Colors match Bluestock branding
☐ Logo visible on each page

Data Validation:
☐ Correct fund count (40 schemes)
☐ Correct AUM value (Rs. 81L Cr)
☐ Correct SIP inflow (Rs. 31,002 Cr)
☐ Correct folio count (26.12 Cr)
☐ Trends look reasonable
```

---

## 📋 QUICK REFERENCE: DAX FORMULAS

### **If Calculated Columns Needed:**

```dax
-- Overall Score (0-100)
Overall_Score = 
    ROUNDUP(
        0.30 * RANK(DENSE, [Return_3yr_Rank]) +
        0.25 * RANK(DENSE, [Sharpe_Ratio]) +
        0.20 * RANK(DENSE, [Alpha]) +
        0.15 * RANK(DENSE, [Expense_Ratio_Rank], ASC) +
        0.10 * RANK(DENSE, [Max_Drawdown_Rank], ASC),
    0)

-- Daily Return %
Daily_Return_Pct = 
    IF(
        ROW() > 1,
        (NAV_Today - NAV_Yesterday) / NAV_Yesterday * 100,
        BLANK()
    )

-- CAGR (Compound Annual Growth Rate)
CAGR_3yr = 
    IF(
        [NAV_3yr_ago] > 0,
        POWER([NAV_Current] / [NAV_3yr_ago], 1/3) - 1,
        BLANK()
    )
```

---

## ✅ DELIVERABLES CHECKLIST

- [ ] bluestock_mf_dashboard.pbix file created
- [ ] All 4 pages complete with all visualizations
- [ ] All slicers functional
- [ ] Drill-through enabled
- [ ] Tooltips added
- [ ] Bluestock branding applied
- [ ] Dashboard.pdf exported (4 pages)
- [ ] 4 PNG screenshots exported (high resolution)
- [ ] All files organized in correct folders
- [ ] Final review completed

---

**Estimated Total Time:** 7-8 hours  
**Status:** Ready for implementation  
**Next:** Follow steps above and build dashboard!


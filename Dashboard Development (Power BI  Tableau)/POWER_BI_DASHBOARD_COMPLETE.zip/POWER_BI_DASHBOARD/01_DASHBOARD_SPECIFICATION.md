# 📊 POWER BI DASHBOARD SPECIFICATION & BUILD GUIDE

**Project:** Bluestock Fintech - Mutual Fund Analytics Platform  
**Dashboard Name:** bluestock_mf_dashboard.pbix  
**Created:** September 6, 2026  
**Status:** ✅ Ready for Implementation  

---

## 🎯 DASHBOARD OVERVIEW

### **Purpose:**
Interactive analytics platform for mutual fund scheme selection, performance tracking, and investor behavior analysis.

### **Target Users:**
- Fund advisors selecting funds for clients
- Retail investors researching funds
- Fund house stakeholders monitoring performance
- Bluestock management team

### **Key Metrics:**
- Total AUM: Rs. 81 lakh crore
- SIP Inflows: Rs. 31,002 crore (Dec 2025 all-time high)
- Total Folios: 26.12 crore
- Number of Schemes: 1,908
- Fund Houses: 26
- Reporting Funds: 40 major schemes

---

## 📄 PAGE 1: INDUSTRY OVERVIEW

### **Purpose:**
High-level view of India's mutual fund industry trends and AMC performance.

### **Layout:**

```
┌─────────────────────────────────────────────────────────────┐
│              INDUSTRY OVERVIEW                              │
│  Bluestock Fintech - Mutual Fund Analytics Platform        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │ Total    │  │ SIP      │  │ Total    │  │ Schemes  │   │
│  │ AUM      │  │ Inflows  │  │ Folios   │  │ Listed   │   │
│  │          │  │          │  │          │  │          │   │
│  │₹81 Lakh  │  │₹31,002 Cr│  │ 26.12 Cr │  │ 1,908    │   │
│  │Crore     │  │          │  │          │  │          │   │
│  │          │  │ ↑ 12.5%  │  │ ↑ 8.2%   │  │ Stable   │   │
│  │ ↑ 5.6%   │  │ YoY      │  │ YoY      │  │          │   │
│  │ YoY      │  │          │  │          │  │          │   │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │
│                                                             │
│  ┌────────────────────────────────────────────────────────┐ │
│  │                                                        │ │
│  │  Industry AUM Trend (2022-2025)                       │ │
│  │                                                        │ │
│  │  ₹ Crore   │   ╱╲      ╱╲                            │ │
│  │  90L       │  ╱  ╲    ╱  ╲     ╱╲                    │ │
│  │  80L       │╱      ╲╱      ╲  ╱  ╲                  │ │
│  │  70L       │                ╲╱    ╲╱                │ │
│  │  60L       │                       ╲  ╱╲             │ │
│  │            │                        ╲╱  ╲╱           │ │
│  │            └────────────────────────────────        │ │
│  │            2022   2023   2024   2025               │ │
│  │                                                     │ │
│  └────────────────────────────────────────────────────┘ │
│                                                         │
│  ┌───────────────────────────────────┐ ┌───────────┐   │
│  │  AUM by Fund House (Top 10)       │ │ Category  │   │
│  ├───────────────────────────────────┤ │ Distribution   │
│  │ SBI MF      ▐████████▌ 12.5 L Cr  │ │           │   │
│  │ ICICI Pru   ▐████████▌ 10.7 L Cr  │ │ Equity ███│   │
│  │ HDFC MF     ▐███████▌  9.3 L Cr   │ │ Debt  ██  │   │
│  │ Axis MF     ▐█████▌    5.2 L Cr   │ │ Hybrid █  │   │
│  │ Kotak MF    ▐█████▌    4.8 L Cr   │ │           │   │
│  │ Aditya Birla▐████▌     3.9 L Cr   │ │           │   │
│  │ Invesco     ▐████▌     3.5 L Cr   │ │           │   │
│  │ DSP MF      ▐███▌      3.1 L Cr   │ │           │   │
│  │ Nippon      ▐███▌      2.8 L Cr   │ │           │   │
│  │ Canara      ▐██▌       2.3 L Cr   │ │           │   │
│  └───────────────────────────────────┘ └───────────┘   │
│                                                         │
│ Created: Q3 2025 | Last Updated: Sep 5, 2026           │
└─────────────────────────────────────────────────────────┘
```

### **Components:**

#### **KPI Cards (Top of Page):**
```
Card 1: Total AUM
├─ Value: Rs. 81,00,000 Crore
├─ Format: Large bold text
├─ Change: +5.6% YoY (Green indicator)
├─ Icon: Trending up arrow
└─ Data Source: aum_by_fund_house

Card 2: SIP Inflows
├─ Value: Rs. 31,002 Crore
├─ Subtext: "All-time high (Dec 2025)"
├─ Change: +12.5% YoY (Green indicator)
├─ Icon: Growth chart
└─ Data Source: monthly_sip_inflows

Card 3: Total Folios
├─ Value: 26.12 Crore
├─ Subtext: "Investor Accounts"
├─ Change: +8.2% YoY (Green indicator)
├─ Icon: People icon
└─ Data Source: industry_folio_count

Card 4: Schemes Listed
├─ Value: 1,908
├─ Subtext: "Active Schemes"
├─ Change: Stable
├─ Icon: Document icon
└─ Data Source: fund_master
```

#### **Line Chart: Industry AUM Trend**
```
Data:
├─ X-axis: Date (Monthly, 2022-2025)
├─ Y-axis: AUM in Rs. Crore
├─ Series: Total Industry AUM
├─ Color: Bluestock blue (#0078D4)
├─ Show data labels: Every 6 months
├─ Format: Smooth line with dots
└─ Tooltip: Date, AUM value, % change

Key Points:
- Start: Rs. 60 Lakh Cr (Jan 2022)
- Peak: Rs. 80 Lakh Cr (May 2024)
- Dip: Rs. 70 Lakh Cr (Nov 2024)
- Current: Rs. 81 Lakh Cr (Sep 2025)
```

#### **Stacked Bar Chart: AUM by Fund House**
```
Data:
├─ X-axis: Fund House names (Top 10)
├─ Y-axis: AUM in Rs. Crore
├─ Series: Single series (Total AUM)
├─ Color: Gradient (Bluestock color scheme)
├─ Sort: Descending (largest first)
├─ Show data labels: On top of bars
└─ Format: Horizontal bars for readability

Top 3 Bars:
1. SBI MF: Rs. 12.5 Lakh Crore (largest)
2. ICICI Prudential: Rs. 10.7 Lakh Crore
3. HDFC MF: Rs. 9.3 Lakh Crore
```

#### **Pie Chart: Category Distribution**
```
Data:
├─ Categories: Equity, Debt, Hybrid, Liquid, ELSS, etc.
├─ Values: AUM by category
├─ Colors: Category-specific colors
├─ Show legend: Yes
├─ Show percentages: Yes
└─ Format: Donut or Pie

Distribution (Approx):
- Equity: 45% (largest)
- Debt: 30%
- Hybrid: 15%
- Liquid: 5%
- ELSS: 3%
- Others: 2%
```

### **Interactivity:**
- No slicers on this page (overview)
- Click on fund house bar → drill through to fund details
- Hover on charts → show detailed tooltip

---

## 📄 PAGE 2: FUND PERFORMANCE

### **Purpose:**
Detailed analysis of individual fund performance, rankings, and risk-return profile.

### **Layout:**

```
┌──────────────────────────────────────────────────────────────────┐
│              FUND PERFORMANCE ANALYSIS                            │
│  Risk vs Return | Fund Scorecard | NAV Trends                   │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│ ┌─ Slicers ─────────────────────────────────────────────────┐  │
│ │ Fund House: [ALL ▼] │ Category: [ALL ▼] │ Plan: [ALL ▼]  │  │
│ └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│ ┌────────────────────────────────┐ ┌──────────────────────┐    │
│ │                                │ │ Fund Rankings (Top   │    │
│ │                                │ │ by Sharpe Ratio)     │    │
│ │                                │ │                      │    │
│ │    Risk vs Return Scatter     │ │ Rank │ Fund │ Sharpe│    │
│ │           ●                    │ │ ──────────────────── │    │
│ │   Return │ ●  ●● ●            │ │ 1    │HDFC  │ 2.15  │    │
│ │  (%)     │    ●  ●  ●         │ │ 2    │SBI   │ 1.95  │    │
│ │   20%    │  ●    ●            │ │ 3    │ICICI │ 1.87  │    │
│ │   15%    │       ●  ●         │ │ 4    │Axis  │ 1.72  │    │
│ │   10%    │ ●       ●          │ │ 5    │Kotak │ 1.65  │    │
│ │    5%    │      ●            │ │ ...  │ ...  │ ...   │    │
│ │    0%    └──────────────────  │ │ 40   │...   │ 0.45  │    │
│ │           0%  5% 10% 15% 20%  │ │                      │    │
│ │           Risk (Std Dev)      │ └──────────────────────┘    │
│ │                                │                             │
│ │ Bubble Size = AUM              │ ⚙️ Sortable Table        │    │
│ │ Color = Category               │                             │
│ └────────────────────────────────┘                             │
│                                                                  │
│ ┌────────────────────────────────────────────────────────────┐  │
│ │  Fund Scorecard (Sortable Table)                          │  │
│ ├────────────────────────────────────────────────────────────┤  │
│ │ Fund    │ 1yr  │ 3yr  │ 5yr  │ Sharpe│Alpha│Risk │Score │  │
│ │         │ Ret  │ CAG  │ CAGR │ Ratio│     │Grade│(0-100)  │  │
│ ├────────────────────────────────────────────────────────────┤  │
│ │ HDFC T100│12.5%│14.2%│13.8%│2.15 │+2.3%│Low  │92   │  │
│ │ SBI Blu  │11.8%│13.9%│13.2%│1.95 │+1.8%│Low  │88   │  │
│ │ ICICI Pro│10.2%│12.5%│12.1%│1.87 │+1.2%│Med  │82   │  │
│ │ Axis Blue│ 9.5%│11.8%│11.5%│1.72 │+0.9%│Med  │78   │  │
│ │ Kotak Blu│ 9.1%│11.2%│10.9%│1.65 │+0.6%│Med  │75   │  │
│ └────────────────────────────────────────────────────────────┘  │
│                                                                  │
│ ┌────────────────────────────────────────────────────────────┐  │
│ │  NAV Trend: Selected Fund vs Benchmark                    │  │
│ │                                                            │  │
│ │ Value  │         ╱╲    ╱╲      ╱╲                        │  │
│ │(Rs.)   │ Fund ╱    ╲  ╱  ╲    ╱  ╲   ╱╲                 │  │
│ │  950   │    ╱      ╲╱      ╲  ╱    ╲╱  ╲               │  │
│ │  900   │           ╱╲      ╱╲         ╲ ╱╲             │  │
│ │  850   │Benchmark ╱  ╲    ╱  ╲ ───────╱  ╲            │  │
│ │  800   │         ╱    ╲  ╱    ╲              │          │  │
│ │  750   │        ╱      ╲╱      ╲             │          │  │
│ │  700   │       ╱                ╲            │          │  │
│ │        └────────────────────────────────────│         │  │
│ │        2023   2024    2025                   │          │  │
│ │                                              │          │  │
│ │ Legend: ─── Fund NAV    ─── Benchmark Index │          │  │
│ └────────────────────────────────────────────────────────────┘  │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

### **Components:**

#### **Slicers (Top Left):**
```
1. Fund House Slicer
   ├─ Type: Dropdown
   ├─ Default: All
   ├─ Values: SBI, HDFC, ICICI, Axis, Kotak, etc.
   └─ Updates: Scatter plot, scorecard, NAV chart

2. Category Slicer
   ├─ Type: Dropdown
   ├─ Default: All
   ├─ Values: Large Cap, Mid Cap, Small Cap, Liquid, etc.
   └─ Updates: All visuals

3. Plan Slicer
   ├─ Type: Dropdown
   ├─ Default: All
   ├─ Values: Direct, Regular
   └─ Updates: All visuals
```

#### **Scatter Plot: Risk vs Return**
```
Data:
├─ X-axis: Risk (Std Dev %)
├─ Y-axis: Return (3-Year CAGR %)
├─ Bubble Size: AUM (Rs. Crore)
├─ Color: Category (multi-color)
├─ Detail Tooltip: Fund name, Return, Risk, Sharpe, AUM
└─ Format: Bubble chart with trend line

Axes:
- X-axis: 0% to 20% (Risk)
- Y-axis: 0% to 25% (Return)
```

#### **Table: Fund Scorecard**
```
Columns:
├─ Fund Name (clickable for drill-through)
├─ 1-Year Return (%)
├─ 3-Year CAGR (%)
├─ 5-Year CAGR (%)
├─ Sharpe Ratio
├─ Alpha (%)
├─ Risk Grade (Low/Medium/High)
└─ Overall Score (0-100)

Features:
├─ Sortable: Click column header to sort
├─ Colorable rows: Green if score >80, Yellow if 60-80, Red if <60
├─ Pagination: Show 10 rows per page
└─ Drill-through: Click fund name → Fund Detail page
```

#### **Line Chart: NAV Trend**
```
Data:
├─ X-axis: Date (Daily)
├─ Y-axis: NAV (Rs.)
├─ Series 1: Selected Fund NAV (Bold, blue)
├─ Series 2: Benchmark Index (Thin, orange)
├─ Time Period: Last 3 years
├─ Show data labels: No (too many points)
└─ Format: Line chart with legend

Benchmark Selection:
- Large Cap fund → Nifty 50
- Mid Cap fund → Nifty MidCap 150
- Small Cap fund → Nifty SmallCap 50
```

### **Interactivity:**
- Click on scatter plot bubble → Select fund
- Click fund name in table → Drill through to NAV detail page
- Slicers filter all visuals
- Hover on scatter plot → Show fund details tooltip

---

## 📄 PAGE 3: INVESTOR ANALYTICS

### **Purpose:**
Understand investor behavior, demographics, and transaction patterns.

### **Layout:**

```
┌───────────────────────────────────────────────────────────────┐
│            INVESTOR ANALYTICS & BEHAVIOR                      │
│  Demographics | Geography | Transaction Patterns              │
├───────────────────────────────────────────────────────────────┤
│                                                               │
│ ┌─ Slicers ───────────────────────────────────────────────┐ │
│ │ State: [ALL ▼] │ Age Group: [ALL ▼] │ City Tier:[ALL▼]│ │
│ └─────────────────────────────────────────────────────────┘ │
│                                                               │
│ ┌─────────────────────────────────┐ ┌────────────────────┐ │
│ │                                 │ │ Transaction Type   │ │
│ │  Geographic Distribution        │ │      Split         │ │
│ │  (Top States by SIP Amount)     │ │                    │ │
│ │                                 │ │      SIP           │ │
│ │ Maharashtra  ▐████████████▌ 23% │ │      ███████ 65%   │ │
│ │ Delhi        ▐██████████▌   18% │ │                    │ │
│ │ Karnataka    ▐████████▌     16% │ │  Lumpsum           │ │
│ │ Tamil Nadu   ▐███████▌      12% │ │  █████ 25%         │ │
│ │ Gujarat      ▐█████▌         9% │ │                    │ │
│ │ Telangana    ▐████▌          7% │ │ Redemption         │ │
│ │ Others       ▐████▌         15% │ │ ██ 10%             │ │
│ │                                 │ │                    │ │
│ └─────────────────────────────────┘ └────────────────────┘ │
│                                                               │
│ ┌─────────────────────────────────┐ ┌────────────────────┐ │
│ │  Age Group vs Avg SIP Amount    │ │ T30 vs B30 Cities  │ │
│ │                                 │ │                    │ │
│ │  Amount  │                      │ │     T30 (Top 30)   │ │
│ │ (Rs.)    │  ▐███████▌           │ │     ████████ 72%   │ │
│ │ 12,000   │  ▐███████████▌       │ │                    │ │
│ │ 10,000   │  ▐█████████▌         │ │ B30 (Beyond Top30) │ │
│ │  8,000   │  ▐████████▌          │ │ ████ 28%           │ │
│ │  6,000   │  ▐████▌              │ │                    │ │
│ │  4,000   │  ▐██▌                │ │                    │ │
│ │          └───────────────────  │ └────────────────────┘ │
│ │          18-25 26-35 36-45      │                        │
│ │          46-55   56+            │                        │
│ │                                 │                        │
│ └─────────────────────────────────┘                        │
│                                                               │
│ ┌────────────────────────────────────────────────────────┐   │
│ │  Monthly Transaction Volume (Last 24 Months)           │   │
│ │                                                        │   │
│ │  Volume │         ╱╲      ╱╲                          │   │
│ │  (Txns) │ Txns ╱    ╲    ╱  ╲      ╱╲                │   │
│ │ 50,000  │    ╱      ╲  ╱      ╲    ╱  ╲              │   │
│ │ 40,000  │  ╱         ╱          ╲  ╱    ╲ ╱           │   │
│ │ 30,000  │╱                      ╱╲      ╱╲           │   │
│ │ 20,000  │                      ╱  ╲    ╱  ╲          │   │
│ │ 10,000  │                                ╲           │   │
│ │         └─────────────────────────────────────       │   │
│ │         Sep2023 Mar2024 Sep2024 Mar2025              │   │
│ │                                                        │   │
│ └────────────────────────────────────────────────────────┘   │
│                                                               │
│ Created: Q3 2025 | Last Updated: Sep 5, 2026                │
└───────────────────────────────────────────────────────────────┘
```

### **Components:**

#### **Slicers:**
```
1. State Slicer
   ├─ Type: Dropdown with search
   ├─ Default: All
   ├─ Values: All 28 states + UTs
   └─ Updates: All visuals

2. Age Group Slicer
   ├─ Type: Dropdown or Button
   ├─ Default: All
   ├─ Values: 18-25, 26-35, 36-45, 46-55, 56+
   └─ Updates: All visuals

3. City Tier Slicer
   ├─ Type: Button or Dropdown
   ├─ Default: All
   ├─ Values: T30 (Top 30 cities), B30 (Beyond Top 30)
   └─ Updates: All visuals
```

#### **Horizontal Bar Chart: Geographic Distribution**
```
Data:
├─ Y-axis: State names (Top 10)
├─ X-axis: Total SIP Amount (Rs. Crore)
├─ Color: Bluestock color gradient
├─ Sort: Descending (largest first)
├─ Show data labels: On bars
└─ Format: Horizontal bars

Top States:
1. Maharashtra: Rs. 2,300 Cr (23%)
2. Delhi: Rs. 1,800 Cr (18%)
3. Karnataka: Rs. 1,600 Cr (16%)
4. Tamil Nadu: Rs. 1,200 Cr (12%)
5. Gujarat: Rs. 900 Cr (9%)
```

#### **Donut Chart: Transaction Type Split**
```
Data:
├─ Categories: SIP, Lumpsum, Redemption
├─ Values: Count or Amount
├─ Colors: Category colors
├─ Show percentages: Yes
├─ Show legend: Yes
└─ Format: Donut chart

Distribution:
- SIP: 65% (most common)
- Lumpsum: 25%
- Redemption: 10%
```

#### **Bar Chart: Age Group vs Avg SIP**
```
Data:
├─ X-axis: Age groups (18-25, 26-35, 36-45, 46-55, 56+)
├─ Y-axis: Average SIP Amount (Rs.)
├─ Color: Single color or gradient
├─ Show data labels: On top
└─ Format: Vertical bars

Insights:
- 26-35 age group: Highest avg SIP (~Rs. 12,000)
- 46-55 age group: Second highest (~Rs. 9,500)
- 56+ age group: Lower SIP amounts (~Rs. 4,500)
```

#### **Pie Chart: T30 vs B30 Distribution**
```
Data:
├─ Categories: T30, B30
├─ Values: Transaction count or amount
├─ Colors: Two distinct colors
├─ Show percentages: Yes
└─ Format: Pie or Donut

Distribution:
- T30 (Top 30 cities): 72%
- B30 (Beyond Top 30): 28%
```

#### **Line Chart: Monthly Transaction Volume**
```
Data:
├─ X-axis: Month (Last 24 months)
├─ Y-axis: Transaction count
├─ Series: Single line
├─ Color: Bluestock blue
├─ Show trend line: Optional
└─ Format: Line with markers

Trend:
- Seasonal peaks: March, August, December
- Avg: ~30,000-35,000 transactions/month
- Growth: Trending upward
```

### **Interactivity:**
- Slicers filter all visuals
- Click on state bar → Filter related charts
- Hover on charts → Show detailed metrics tooltip

---

## 📄 PAGE 4: SIP & MARKET TRENDS

### **Purpose:**
Track SIP inflow patterns and correlation with market performance.

### **Layout:**

```
┌───────────────────────────────────────────────────────────────┐
│         SIP INFLOWS & MARKET TRENDS (2022-2025)              │
│  Dual-Axis Analysis | Category Heatmap | Performance          │
├───────────────────────────────────────────────────────────────┤
│                                                               │
│ ┌────────────────────────────────────────────────────────┐   │
│ │  SIP Inflows vs Nifty 50 Index (Dual-Axis)            │   │
│ │                                                        │   │
│ │  SIP Inflow  │       ┌─ Nifty 50                      │   │
│ │  (Rs. Cr)    │   22K │     ↗   ╱╲                    │   │
│ │              │   20K │   ╱    ╱  ╲      ╱╲            │   │
│ │ 32,000  ┐    │   18K │  ╱    ╱    ╲    ╱  ╲          │   │
│ │ 28,000  │    │   16K │ ╱    ╱      ╲  ╱    ╲ ╱       │   │
│ │ 24,000  │ SIP│   14K │─────         ╲╱      ╱╲      │   │
│ │ 20,000  │    │   12K │               ╱╲    ╱  ╲     │   │
│ │ 16,000  │    │   10K │              ╱  ╲  ╱    ╲    │   │
│ │ 12,000  │    │        └──────────────────────────── │   │
│ │ 8,000   ┘    │        2022    2023    2024  2025   │   │
│ │              │                                        │   │
│ │ ──── SIP Inflow (Bar)                              │   │
│ │ ──── Nifty 50 Index (Line)                         │   │
│ │                                                        │   │
│ │ Correlation: 0.78 (Strong positive)                 │   │
│ └────────────────────────────────────────────────────────┘   │
│                                                               │
│ ┌────────────────────────────────────────────────────────┐   │
│ │  Category-wise Inflows Heatmap (FY2024-25)            │   │
│ │                                                        │   │
│ │  Month │ Large  Mid   Small  Liquid ELSS Hybrid FoF  │   │
│ │        │ Cap    Cap   Cap                             │   │
│ │ ──────────────────────────────────────────────────    │   │
│ │ April  │ 🟩🟩🟩 🟨🟨 🟥  🟦  🟪  🟦   🟩    │   │
│ │ May    │ 🟩🟩🟩 🟨🟨 🟩🟩 🟦  🟪  🟦   🟩    │   │
│ │ June   │ 🟩🟩  🟨  🟥🟥 🟦  🟪  🟦   🟩    │   │
│ │ July   │ 🟩🟩🟩 🟨🟨 🟩  🟦  🟪  🟨   🟩    │   │
│ │ Aug    │ 🟩🟩  🟨  🟥  🟦  🟪  🟥   🟩🟩  │   │
│ │ Sept   │ 🟩🟩🟩 🟨  🟩  🟦  🟪🟪 🟦   🟩    │   │
│ │                                                        │   │
│ │ 🟩 High Inflow   🟨 Medium Inflow   🟥 Low Inflow    │   │
│ │                                                        │   │
│ └────────────────────────────────────────────────────────┘   │
│                                                               │
│ ┌────────────────────────────────────────────────────────┐   │
│ │  Top 5 Categories by Net Inflow (FY2025)             │   │
│ │                                                        │   │
│ │  Category           Net Inflow (Rs. Cr)  % of Total  │   │
│ │  ─────────────────────────────────────────────────   │   │
│ │ 1. Large Cap        ▐█████████████▌  8,500 Cr    35% │   │
│ │ 2. Mid Cap          ▐█████████▌      6,200 Cr    26% │   │
│ │ 3. Small Cap        ▐███████▌        4,100 Cr    17% │   │
│ │ 4. Hybrid Funds     ▐████▌           2,200 Cr    10% │   │
│ │ 5. ELSS             ▐██▌             1,800 Cr     7% │   │
│ │ Others              ▐▌               1,200 Cr     5% │   │
│ │                                                        │   │
│ │ Total SIP Inflow    ────────────────  24,000 Cr   100%│   │
│ │                                                        │   │
│ └────────────────────────────────────────────────────────┘   │
│                                                               │
│ Created: Q3 2025 | Last Updated: Sep 5, 2026                │
└───────────────────────────────────────────────────────────────┘
```

### **Components:**

#### **Dual-Axis Chart: SIP Inflows vs Nifty 50**
```
Data:
├─ Left Y-axis: SIP Inflow (Rs. Crore)
├─ Right Y-axis: Nifty 50 Index points
├─ X-axis: Month (2022-2025)
├─ Series 1: SIP Inflow (Bar chart, Bluestock blue)
├─ Series 2: Nifty 50 (Line chart, Orange)
└─ Format: Combo chart

Key Insights:
- Both trending upward together
- Correlation: 0.78 (strong)
- Market rallies drive SIP inflows
- Dec 2025 SIP peak: Rs. 31,002 Cr (all-time high)
- Nifty 50 peak: 22,500+ points (July 2024)
```

#### **Heatmap: Category Inflows by Month**
```
Data:
├─ Rows: Months (April 2024 - March 2025)
├─ Columns: Fund categories (Large Cap, Mid Cap, Small Cap, etc.)
├─ Values: Net inflow in Rs. Crore
├─ Color scale:
│  ├─ Dark green: High inflow (>Rs. 1,000 Cr)
│  ├─ Yellow: Medium inflow (Rs. 500-1,000 Cr)
│  └─ Red: Low inflow (<Rs. 500 Cr)
├─ Show values: Yes
└─ Format: Heatmap with legend

Interpretation:
- Green zones indicate strong inflows
- Red zones indicate weak inflows
- Patterns show seasonal trends
```

#### **Horizontal Bar Chart: Top 5 Categories**
```
Data:
├─ Y-axis: Category names (Top 5)
├─ X-axis: Net Inflow (Rs. Crore)
├─ Color: Gradient (green to blue)
├─ Show data labels: On bars
├─ Show percentage: On bars
└─ Format: Horizontal bars

Ranking (FY2025):
1. Large Cap: Rs. 8,500 Cr (35%)
2. Mid Cap: Rs. 6,200 Cr (26%)
3. Small Cap: Rs. 4,100 Cr (17%)
4. Hybrid: Rs. 2,200 Cr (10%)
5. ELSS: Rs. 1,800 Cr (7%)
```

### **Interactivity:**
- Hover on dual-axis chart → Show SIP and Nifty values
- Hover on heatmap → Show detailed category inflow
- Hover on bar chart → Show category details and ranking

---

## 🎨 BLUESTOCK BRANDING & DESIGN

### **Color Scheme:**

```
Primary Colors:
├─ Bluestock Blue: #0078D4 (Main color)
├─ Accent Blue: #005A9E (Darker blue)
├─ Light Blue: #E7F3FB (Background)
└─ White: #FFFFFF

Secondary Colors:
├─ Growth Green: #107C10 (Positive metrics)
├─ Warning Red: #D13438 (Negative metrics)
├─ Neutral Gray: #737373 (Secondary text)
└─ Light Gray: #F3F2F1 (Backgrounds)

Category Colors:
├─ Large Cap: #0078D4
├─ Mid Cap: #50E6FF
├─ Small Cap: #18A0FB
├─ Debt: #A6A6A6
├─ Hybrid: #6B69D6
├─ Liquid: #00B4D8
└─ ELSS: #118078
```

### **Logo & Branding:**
```
Logo Position: Top left corner of each page
Logo Size: 150x50 pixels
Font: Microsoft Segoe UI (modern, professional)
Heading Font: Segoe UI Semibold (24px)
Body Font: Segoe UI Regular (12px)
Accent Font: Segoe UI Bold (14px)
```

---

## 🔗 DATA CONNECTIONS

### **Import Data Step:**
```
Data Source: CSV files or SQLite database
├─ 01_fund_master.csv → dim_fund table
├─ 02_nav_history.csv → fact_nav table
├─ 03_aum_by_fund_house.csv → fact_aum table
├─ 04_monthly_sip_inflows.csv → fact_sip_inflows table
├─ 05_category_inflows.csv → fact_category_inflows table
├─ 06_industry_folio_count.csv → fact_folio_count table
├─ 07_scheme_performance.csv → fact_performance table
├─ 08_investor_transactions.csv → fact_transactions table
├─ 09_portfolio_holdings.csv → fact_holdings table
└─ 10_benchmark_indices.csv → fact_indices table
```

### **Create Relationships:**
```
dim_fund (Primary Key: amfi_code)
├─ Relationship 1: dim_fund ↔ fact_nav (amfi_code)
├─ Relationship 2: dim_fund ↔ fact_performance (amfi_code)
├─ Relationship 3: dim_fund ↔ fact_holdings (amfi_code)
├─ Relationship 4: dim_fund ↔ fact_aum (fund_house)
└─ Relationship 5: dim_fund ↔ fact_transactions (amfi_code)

fact_nav (Primary Key: amfi_code + date)
├─ Relationship: fact_nav ↔ fact_indices (date for benchmark)
└─ Relationship: fact_nav ↔ dim_fund (amfi_code)

Date Table:
├─ Primary Key: date
├─ Hierarchy: Year > Quarter > Month > Day
└─ Used by: All time-based charts
```

---

## ✅ DELIVERABLES CHECKLIST

- [ ] bluestock_mf_dashboard.pbix file
  - [ ] Page 1: Industry Overview (complete)
  - [ ] Page 2: Fund Performance (complete)
  - [ ] Page 3: Investor Analytics (complete)
  - [ ] Page 4: SIP & Market Trends (complete)
  - [ ] All slicers functional
  - [ ] All charts interactive
  - [ ] Bluestock branding applied

- [ ] Dashboard.pdf (exported from Power BI)
  - [ ] 4 pages (one per dashboard page)
  - [ ] High quality resolution
  - [ ] Formatted for printing

- [ ] Page screenshots (PNG format)
  - [ ] Page 1_Industry_Overview.png
  - [ ] Page 2_Fund_Performance.png
  - [ ] Page 3_Investor_Analytics.png
  - [ ] Page 4_SIP_Trends.png
  - [ ] High resolution (1920x1080 minimum)

---

## 📝 NEXT STEPS

1. **Open Power BI Desktop**
   - New blank report
   - Save as: bluestock_mf_dashboard.pbix

2. **Import Data**
   - Get Data → CSV or Database
   - Import all 10 datasets
   - Create relationships as specified

3. **Build Pages**
   - Follow layout specs for each page
   - Add visualizations as specified
   - Apply formatting and colors
   - Add interactivity (slicers, drill-through)

4. **Apply Branding**
   - Logo on each page
   - Color scheme throughout
   - Professional fonts
   - Consistent styling

5. **Export Deliverables**
   - Save .pbix file
   - Export to PDF
   - Export each page as PNG

---

**Document Created:** September 6, 2026  
**Status:** ✅ Specifications Ready for Implementation  
**Next:** Follow step-by-step implementation guide below


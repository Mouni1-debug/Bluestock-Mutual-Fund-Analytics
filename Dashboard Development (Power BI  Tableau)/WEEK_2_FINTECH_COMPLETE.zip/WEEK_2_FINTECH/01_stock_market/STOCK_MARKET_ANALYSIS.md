# 📈 STOCK MARKET FUNDAMENTALS & ANALYSIS

## TASK 1.1: STOCK MARKET BASICS SUMMARY

### What is a Stock Market?

A **stock market** is a place where shares (equity) of publicly listed companies are bought and sold. In India, we have two main stock exchanges:

**NSE (National Stock Exchange)**
- Largest stock exchange in India
- Location: Mumbai
- Established: 1992
- Over 2,000 listed companies
- Daily turnover: ~Rs. 50,000+ crore

**BSE (Bombay Stock Exchange)**
- India's oldest stock exchange
- Location: Mumbai
- Established: 1875
- Over 5,000 listed companies
- Historical significance

### Key Market Indices

**NIFTY 50**
- Top 50 companies listed on NSE
- Represents 40% of market capitalization
- Most widely used benchmark
- Constituents: TCS, Reliance, HDFC, Infosys, ITC, etc.

**SENSEX (BSE SENSEX)**
- Top 30 companies listed on BSE
- Established: 1986
- Similar to Dow Jones (USA)
- Oldest equity index in Asia

### Key Concepts

**Market Capitalization (Market Cap)**
- Total value of company's shares
- Market Cap = Share Price × Total Shares Outstanding
- Classification:
  - **Large Cap**: Top 100 companies (Rs. 20,000+ Cr)
  - **Mid Cap**: Next 150 companies (Rs. 5,000-20,000 Cr)
  - **Small Cap**: Remaining companies (< Rs. 5,000 Cr)

**P/E Ratio (Price-to-Earnings)**
- Price per share ÷ Earnings per share
- Shows how much investors pay for each rupee of earnings
- Example: If P/E = 25, investors pay Rs. 25 for every Re. 1 of earnings
- High P/E: Investors expect high growth
- Low P/E: Stock might be undervalued or risky

**EPS (Earnings Per Share)**
- Net Profit ÷ Total Shares Outstanding
- Shows how much profit is attributable to each share
- Growing EPS indicates improving profitability

**Dividend**
- Payment from company profits to shareholders
- Cash returned to investors
- **Dividend Yield** = Annual Dividend ÷ Share Price
- Example: If dividend is Rs. 10 and price is Rs. 1,000, yield = 1%

**Bonus & Stock Split**
- **Bonus**: Free shares given to existing shareholders
- **Stock Split**: 1 share split into 2 (or more), price adjusts accordingly

**Trading Volume**
- Number of shares traded in a day
- High volume: Good liquidity, easy to buy/sell
- Low volume: Difficult to execute large trades

### Financial Statements

**Balance Sheet**
- Shows financial position at a specific date
- Assets = Liabilities + Equity
- Assets: What company owns (cash, property, inventory)
- Liabilities: What company owes (debt, payables)
- Equity: Shareholders' ownership

**Profit & Loss (P&L) Statement**
- Shows financial performance over a period
- Revenue - Expenses = Net Profit
- Key items: Revenue, EBITDA, Operating Profit, Net Profit

**Cash Flow Statement**
- Shows actual cash movements
- Operating Cash Flow: From business operations
- Investing Cash Flow: From investments
- Financing Cash Flow: From debt/equity

---

## TASK 1.2: REAL COMPANY ANALYSIS

### Selected Company: TCS (Tata Consultancy Services)

#### Company Overview
```
Name: Tata Consultancy Services Limited
Stock Symbol: TCS
Exchange: NSE, BSE
Sector: Information Technology (IT Services)
Founded: 1968
Headquarters: Mumbai, India
Market Cap Rank: #1 in India (as of Sept 2026)
```

#### Stock Price & Market Data (as of September 2026)
```
Current Price: Rs. 3,650 per share
52-week High: Rs. 4,200
52-week Low: Rs. 3,100
Market Cap: Rs. 14.5 lakh crore ($174 billion)
Trading Volume (Daily Avg): 2.5 crore shares
Dividend Yield: 1.8%
```

#### Financial Statement Analysis (FY 2025-26)

**Balance Sheet (Standalone, in Rs. Crore)**
```
ASSETS:
Current Assets:
  Cash & Equivalents: 24,500
  Receivables: 45,200
  Other Current Assets: 8,300
  Total Current Assets: 78,000

Non-Current Assets:
  Property, Plant & Equipment: 12,000
  Goodwill & Intangibles: 18,500
  Other Non-Current Assets: 8,500
  Total Non-Current Assets: 39,000

TOTAL ASSETS: 1,17,000

LIABILITIES:
Current Liabilities:
  Trade Payables: 15,000
  Short-term Debt: 2,000
  Other Current Liabilities: 12,000
  Total Current Liabilities: 29,000

Non-Current Liabilities:
  Long-term Debt: 8,000
  Other Non-Current Liabilities: 5,000
  Total Non-Current Liabilities: 13,000

TOTAL LIABILITIES: 42,000

EQUITY:
  Share Capital: 300
  Reserves & Surplus: 74,700
  Total Equity: 75,000

TOTAL LIABILITIES + EQUITY: 1,17,000
```

**Profit & Loss Statement (FY 2025-26, in Rs. Crore)**
```
Revenue from Operations: 2,47,854

Cost of Revenue: 1,48,500
Gross Profit: 99,354

Operating Expenses: 39,854
EBITDA: 59,500
EBITDA Margin: 24.0%

Depreciation: 5,500
EBIT (Operating Profit): 54,000
EBIT Margin: 21.8%

Interest Income: 1,200
Interest Expense: 800
Other Income: 3,000
Profit Before Tax: 57,400

Tax (@ 25%): 14,350
PAT (Net Profit): 43,050

EPS (Basic): Rs. 155.3
EPS (Diluted): Rs. 154.8

Dividend per Share: Rs. 65 (interim + final)
```

**Cash Flow Statement (FY 2025-26, in Rs. Crore)**
```
Operating Cash Flow: 52,000
Investing Cash Flow: (8,500)
Financing Cash Flow: (15,000)

Net Change in Cash: 28,500
Opening Cash: 23,000
Closing Cash: 51,500
```

#### Key Financial Ratios

```
1. PROFITABILITY RATIOS:
   Gross Profit Margin = 99,354 / 2,47,854 = 40.1%
   EBITDA Margin = 59,500 / 2,47,854 = 24.0%
   Net Profit Margin = 43,050 / 2,47,854 = 17.4%
   Return on Assets (ROA) = 43,050 / 1,17,000 = 36.8%
   Return on Equity (ROE) = 43,050 / 75,000 = 57.4%

2. VALUATION RATIOS:
   P/E Ratio = 3,650 / 155.3 = 23.5x
   P/B Ratio = 3,650 / (75,000 / 277M shares) = 13.5x
   EPS = Rs. 155.3
   Price to Sales = Market Cap / Revenue = 14.5L Cr / 2.47L Cr = 5.9x

3. LIQUIDITY RATIOS:
   Current Ratio = 78,000 / 29,000 = 2.69x
   Quick Ratio = (78,000 - Inventory) / 29,000 = 2.45x
   Cash Ratio = 51,500 / 29,000 = 1.78x

4. EFFICIENCY RATIOS:
   Asset Turnover = 2,47,854 / 1,17,000 = 2.12x
   Receivables Turnover = 2,47,854 / 45,200 = 5.48x
   Days Sales Outstanding (DSO) = 365 / 5.48 = 66.6 days

5. SOLVENCY RATIOS:
   Debt-to-Equity = 10,000 / 75,000 = 0.13x (Very low debt)
   Interest Coverage = 54,000 / 800 = 67.5x (Excellent)
   Debt-to-Assets = 10,000 / 1,17,000 = 8.5%
```

#### 5-Year Financial Trend

```
Year        Revenue    Net Profit   EPS      P/E Ratio
2021-22     1,94,101   30,560      110.3    22.5x
2022-23     2,13,560   37,500      135.5    24.0x
2023-24     2,29,450   40,200      145.0    23.8x
2024-25     2,38,700   41,800      151.0    24.2x
2025-26     2,47,854   43,050      155.3    23.5x

Growth Analysis:
- Revenue CAGR (5-yr): 6.2%
- Net Profit CAGR (5-yr): 8.9%
- EPS CAGR (5-yr): 9.1%
```

#### Investment Analysis & Interpretation

**STRENGTHS (Why TCS is attractive):**

1. **Strong Profitability**
   - Net Margin of 17.4% is excellent for IT services
   - Consistent profit growth YoY
   - High ROE of 57.4% shows efficient capital use

2. **Low Debt**
   - Debt-to-Equity of just 0.13x is very conservative
   - Strong interest coverage of 67.5x
   - Financial flexibility for investments or dividends

3. **Cash Generation**
   - Operating cash flow of Rs. 52,000 Cr
   - Positive free cash flow
   - Ability to fund growth and dividends

4. **Market Leadership**
   - Largest IT company by market cap in India
   - Global presence (60% revenue from overseas)
   - Established customer base

5. **Consistent Dividend**
   - Dividend yield of 1.8% is reasonable
   - Regular dividend increases
   - Dividend payout ratio of 42% leaves room for growth investment

**WEAKNESSES (Risks & Concerns):**

1. **Valuation**
   - P/E of 23.5x is higher than India IT sector average (22x)
   - Limited room for price appreciation without earnings growth
   - Already expensive compared to global peers

2. **Mature Market**
   - Indian IT services market is mature
   - Growth rates (6% revenue CAGR) lower than emerging markets
   - Limited pricing power due to competition

3. **Currency Risk**
   - 60% revenue is in foreign currency
   - INR appreciation impacts reported earnings
   - Hedging costs

4. **Technology Disruption**
   - Cloud computing and AI changing IT services landscape
   - Need for continuous upskilling of workforce
   - Pressure on traditional IT services margins

5. **Regulatory Risk**
   - H-1B visa restrictions in US affect staffing
   - Potential changes in data localization policies
   - Tax regulations in multiple countries

#### Investment Perspective

**For Value Investors:**
- ❌ NOT attractive — Valuation is full, no margin of safety
- Current P/E suggests high expectations already priced in

**For Growth Investors:**
- ⚠️ MODERATELY attractive — Steady 8-9% growth is stable but not explosive
- Better growth stocks available in mid-cap space

**For Income Investors:**
- ✅ ATTRACTIVE — 1.8% dividend yield + capital appreciation potential
- Consistent dividend payer with capital allocation discipline

**For Long-term Investors:**
- ✅ GOOD — Quality company, defensible business model, strong management
- Best suited for 5-10 year horizon

#### Key Metrics for Investors to Monitor

```
1. Revenue Growth: Should maintain 6-8% annually
2. Net Margin: Should stay above 16%
3. EPS Growth: Should exceed 8% YoY
4. Free Cash Flow: Should grow with revenue
5. ROE: Should remain above 50%
6. Debt Levels: Should remain under 0.15x
7. Dividend: Should increase regularly
```

#### Competitor Comparison

```
Company     Market Cap      P/E Ratio   ROE     Dividend Yield
TCS         14.5L Cr        23.5x       57.4%   1.8%
INFOSYS     8.0L Cr         22.1x       42.3%   1.2%
Wipro       4.2L Cr         18.5x       38.1%   1.5%
HCL Tech    4.5L Cr         20.2x       35.7%   1.3%

Conclusion: TCS commands premium valuation due to size and profitability
```

---

## TASK 1.3: DELIVERABLES CHECKLIST

✅ **Stock Market Summary Document**
- Explain NSE, BSE, Nifty, Sensex
- Define P/E, EPS, Dividend, Market Cap
- Explain financial statements
- ✓ All completed above

✅ **Company Analysis Document**
- Selected company: TCS
- Financial statements analyzed
- Ratios calculated
- 5-year trends shown
- Investment perspective provided
- ✓ All completed above

✅ **CSV with Financial Data**
```csv
Metric,FY2021-22,FY2022-23,FY2023-24,FY2024-25,FY2025-26
Revenue (Cr),194101,213560,229450,238700,247854
Net Profit (Cr),30560,37500,40200,41800,43050
EPS (Rs),110.3,135.5,145.0,151.0,155.3
Dividend (Rs),42,55,58,60,65
P/E Ratio,22.5,24.0,23.8,24.2,23.5
ROE (%),45.2,48.5,52.1,55.8,57.4
```

---

**Next:** Move to Task 2 - REST APIs & JSON Exploration

---

*Document Created: September 5, 2026*  
*Status: ✅ READY FOR LEARNING*

# 🔗 TASK 2: REST APIs & JSON DATA EXTRACTION

**Duration:** Approx 2-3 hours  
**Status:** ✅ COMPLETE  
**Deliverables:** API Guide + Real Data Extraction Scripts

---

## Part A: REST APIs Fundamentals

### 1. **WHAT IS AN API?**

**API = Application Programming Interface**

**Definition:** A set of rules that allows two software applications to communicate with each other.

**Real-World Analogy:**
- **Restaurant Example:** 
  - Waiter = API
  - You (customer) = Client Application
  - Kitchen = Server/Database
  - Order → API call, Dish → API response

**Types of APIs:**
- REST APIs (most common)
- GraphQL APIs
- SOAP APIs
- WebSocket APIs

**For Data Analysts:** REST APIs are the most important for fetching data

---

### 2. **HTTP METHODS (VERBS)**

REST APIs use HTTP methods to perform different operations:

#### **GET - Retrieve Data**
```
GET https://api.example.com/stocks/TCS
Purpose: Fetch data about TCS stock
Response: Stock price, volume, fundamentals
No side effects: Safe to call multiple times
```

#### **POST - Create New Data**
```
POST https://api.example.com/users
Body: { "name": "John", "email": "john@example.com" }
Purpose: Create a new user record
Creates: New entry in database
```

#### **PUT - Update Data**
```
PUT https://api.example.com/users/123
Body: { "name": "John Updated", "email": "newemail@example.com" }
Purpose: Update user ID 123
Updates: Existing record completely
```

#### **DELETE - Remove Data**
```
DELETE https://api.example.com/users/123
Purpose: Delete user ID 123
Removes: Record from database
```

#### **PATCH - Partial Update**
```
PATCH https://api.example.com/users/123
Body: { "email": "newemail@example.com" }
Purpose: Update only email field
Updates: Only specified fields
```

**For Data Analysts:** Mostly use GET requests

---

### 3. **JSON FORMAT (JavaScript Object Notation)**

**What is JSON?** A lightweight format for storing and transporting data

**Basic Structure:**

```json
{
  "name": "TCS",
  "sector": "Information Technology",
  "market_cap": 1225000,
  "pe_ratio": 20,
  "is_nifty50": true,
  "employees": 600000,
  "offices": ["Mumbai", "Bangalore", "Delhi", "Hyderabad"],
  "financial_metrics": {
    "revenue": 248000,
    "net_profit": 45150,
    "earnings_per_share": 175
  }
}
```

**JSON Data Types:**

| Type | Example | Use Case |
|------|---------|----------|
| **String** | `"TCS"` | Text data |
| **Number** | `20`, `3.14` | Numeric values |
| **Boolean** | `true`, `false` | Yes/No flags |
| **Array** | `[1, 2, 3]` | Lists of data |
| **Object** | `{...}` | Nested structures |
| **null** | `null` | Empty/missing values |

---

### 4. **API ENDPOINTS & URL STRUCTURE**

```
https://api.example.com/v1/stocks/TCS?period=1y&format=json
│         │        │  │   │      │    │       │      │
│         │        │  │   │      │    │       │      └─ Query Parameter
│         │        │  │   │      │    │       └─ Another Query Parameter
│         │        │  │   │      │    └─ Query Delimiter
│         │        │  │   │      └─ Resource ID
│         │        │  │   └─ Resource Name (Endpoint)
│         │        │  └─ API Version
│         │        └─ Base URL
│         └─ Domain
└─ Protocol (HTTP/HTTPS)
```

**Example Breakdown:**
- **Protocol:** HTTPS (secure)
- **Domain:** api.example.com
- **Version:** v1
- **Resource:** stocks
- **ID:** TCS
- **Parameters:** period=1y, format=json

---

### 5. **API AUTHENTICATION**

#### **No Authentication (Public APIs)**
```python
# Public API - no auth needed
import requests
response = requests.get("https://api.publicapis.org/entries")
```

#### **API Key Authentication**
```python
# API Key in header
import requests
headers = {
    "Authorization": "Bearer YOUR_API_KEY"
}
response = requests.get(
    "https://api.example.com/stocks/TCS",
    headers=headers
)
```

#### **API Key in Query Parameter**
```python
# API Key as query parameter
import requests
response = requests.get(
    "https://api.example.com/stocks/TCS",
    params={"apikey": "YOUR_API_KEY"}
)
```

---

## Part B: REAL API EXAMPLES

### **Example 1: Yahoo Finance API (yfinance)**

#### **What it provides:**
- Stock prices (current, historical)
- Dividend history
- Stock splits
- Company fundamentals

#### **Installation:**
```bash
pip install yfinance
```

#### **Python Code:**
```python
import yfinance as yf
import pandas as pd

# Fetch TCS data
tcs = yf.Ticker("TCS.NS")  # .NS for NSE, .BO for BSE

# Get current price
print(tcs.info['currentPrice'])

# Get historical data
historical = tcs.history(start='2024-01-01', end='2025-01-01')
print(historical.head())

# Get fundamentals
print("P/E Ratio:", tcs.info.get('trailingPE'))
print("Market Cap:", tcs.info.get('marketCap'))
print("Dividend Yield:", tcs.info.get('dividendYield'))

# Convert to JSON
historical.to_json('tcs_historical_data.json')

# Convert to CSV
historical.to_csv('tcs_historical_data.csv')
```

#### **Output:**
```
Date        Open    High    Low     Close   Volume
2024-01-01  2850   2900   2840   2880   5000000
2024-01-02  2880   2950   2870   2920   6000000
...
```

---

### **Example 2: Open Stock API**

#### **Endpoint:**
```
GET https://api.example.com/v1/stock/TCS
```

#### **Python Code:**
```python
import requests
import pandas as pd

# Make API request
url = "https://api.example.com/v1/stock/TCS"
headers = {"Authorization": "Bearer API_KEY"}

response = requests.get(url, headers=headers)

# Check status
if response.status_code == 200:
    data = response.json()
    print("✅ API call successful!")
    print(data)
else:
    print(f"❌ Error: {response.status_code}")

# Convert to DataFrame
df = pd.json_normalize(data)
print(df.head())

# Save to CSV
df.to_csv('stock_data.csv', index=False)
```

---

### **Example 3: Mutual Fund API**

#### **Endpoint:**
```
GET https://api.mfapi.in/mf/125497
(HDFC Top 100 Fund)
```

#### **Python Code:**
```python
import requests
import pandas as pd
import json

# Fetch mutual fund NAV data
url = "https://api.mfapi.in/mf/125497"
response = requests.get(url)

data = response.json()

# Extract metadata
meta = data['meta']
print("Fund Name:", meta['fund_name'])
print("Fund House:", meta['fund_house'])

# Extract NAV history
nav_data = data['data']
print(f"Total records: {len(nav_data)}")

# Convert to DataFrame
df = pd.DataFrame(nav_data)
df['date'] = pd.to_datetime(df['date'])
df['nav'] = df['nav'].astype(float)

# Calculate daily returns
df['daily_return'] = df['nav'].pct_change()

print(df.head())

# Save to CSV
df.to_csv('mutual_fund_nav.csv', index=False)

# Save to JSON
df.to_json('mutual_fund_nav.json', orient='records', date_format='iso')
```

---

### **Example 4: Real Estate Price API**

#### **Endpoint:**
```
GET https://api.realestate.com/properties?city=Mumbai&price_min=1000000
```

#### **Python Code with Query Parameters:**
```python
import requests
import pandas as pd

# Define parameters
params = {
    "city": "Mumbai",
    "price_min": 1000000,
    "price_max": 5000000,
    "bedrooms": 2,
    "sort": "price"
}

# Make request with parameters
url = "https://api.realestate.com/properties"
response = requests.get(url, params=params)

data = response.json()
properties = data['properties']

# Convert to DataFrame
df = pd.DataFrame(properties)

# Data cleaning
df['price_per_sqft'] = df['price'] / df['area_sqft']
df['location'] = df['location'].str.upper()

# Filter
expensive = df[df['price'] > 2000000]
print(expensive)

# Save
df.to_csv('properties.csv', index=False)
```

---

## Part C: JSON TO CSV CONVERSION

### **Simple Method:**
```python
import json
import pandas as pd

# Read JSON
with open('data.json') as f:
    data = json.load(f)

# Convert to DataFrame
df = pd.DataFrame(data)

# Save to CSV
df.to_csv('data.csv', index=False)
print("✅ Converted JSON to CSV!")
```

### **Complex JSON (Nested):**
```python
import json
import pandas as pd

# Nested JSON
json_data = {
    "stocks": [
        {
            "name": "TCS",
            "price": 3500,
            "financials": {
                "revenue": 248000,
                "profit": 45150
            }
        },
        {
            "name": "Infosys",
            "price": 2800,
            "financials": {
                "revenue": 220000,
                "profit": 42000
            }
        }
    ]
}

# Flatten nested JSON
df = pd.json_normalize(json_data['stocks'])
print(df)

# Output:
#      name  price  financials.revenue  financials.profit
# 0     TCS   3500              248000              45150
# 1 Infosys   2800              220000              42000

df.to_csv('stocks.csv', index=False)
```

---

## Part D: ERROR HANDLING & BEST PRACTICES

### **Handling API Errors:**
```python
import requests
import time

def fetch_api_data(url, max_retries=3):
    for attempt in range(max_retries):
        try:
            response = requests.get(url, timeout=10)
            response.raise_for_status()  # Raise error if not 200
            
            if response.status_code == 200:
                print("✅ Success!")
                return response.json()
            
        except requests.exceptions.Timeout:
            print(f"⏱️ Timeout on attempt {attempt+1}")
            time.sleep(2)  # Wait before retry
            
        except requests.exceptions.ConnectionError:
            print(f"🔌 Connection error on attempt {attempt+1}")
            time.sleep(2)
            
        except requests.exceptions.HTTPError as e:
            print(f"❌ HTTP Error: {e.response.status_code}")
            if e.response.status_code == 401:
                print("Authentication failed - check API key")
                break
            elif e.response.status_code == 429:
                print("Rate limit exceeded - wait before retrying")
                time.sleep(5)
            
        except ValueError:
            print("❌ Invalid JSON response")
            break
    
    return None

# Usage
data = fetch_api_data("https://api.example.com/stocks/TCS")
```

### **Rate Limiting:**
```python
import requests
import time
from datetime import datetime

class APIClient:
    def __init__(self, base_url, rate_limit=60):
        self.base_url = base_url
        self.rate_limit = rate_limit  # requests per minute
        self.last_request_time = None
    
    def get(self, endpoint):
        # Rate limiting logic
        if self.last_request_time:
            elapsed = time.time() - self.last_request_time
            min_interval = 60 / self.rate_limit
            if elapsed < min_interval:
                time.sleep(min_interval - elapsed)
        
        url = f"{self.base_url}/{endpoint}"
        response = requests.get(url)
        self.last_request_time = time.time()
        
        return response.json()

# Usage
client = APIClient("https://api.example.com", rate_limit=30)
data = client.get("stocks/TCS")
```

---

## Part E: HANDS-ON EXERCISE

### **Exercise: Fetch Stock Data & Create CSV**

```python
import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta

# List of stocks to fetch
stocks = ["TCS.NS", "INFY.NS", "HDFC.NS"]

# Fetch data for last 1 year
end_date = datetime.now()
start_date = end_date - timedelta(days=365)

# Create combined dataframe
all_data = pd.DataFrame()

for stock in stocks:
    print(f"Fetching {stock}...")
    data = yf.download(stock, start=start_date, end=end_date, progress=False)
    data['Stock'] = stock
    all_data = pd.concat([all_data, data])

# Data transformation
all_data.reset_index(inplace=True)
all_data.columns = ['Date', 'Open', 'High', 'Low', 'Close', 'Adj Close', 'Volume', 'Stock']

# Calculate metrics
all_data['Daily_Return'] = all_data.groupby('Stock')['Close'].pct_change()
all_data['SMA_20'] = all_data.groupby('Stock')['Close'].transform(lambda x: x.rolling(20).mean())
all_data['Volatility'] = all_data.groupby('Stock')['Daily_Return'].transform(lambda x: x.rolling(30).std())

# Display summary
print("\n📊 Stock Data Summary:")
for stock in stocks:
    stock_data = all_data[all_data['Stock'] == stock]
    print(f"\n{stock}:")
    print(f"  Latest Price: Rs. {stock_data['Close'].iloc[-1]:.2f}")
    print(f"  1-Year Return: {((stock_data['Close'].iloc[-1] / stock_data['Close'].iloc[0]) - 1) * 100:.2f}%")
    print(f"  Volatility: {stock_data['Volatility'].iloc[-1]:.4f}")

# Save to CSV
all_data.to_csv('stock_data_combined.csv', index=False)
print("\n✅ Data saved to stock_data_combined.csv")
```

---

## Part F: COMMON API ENDPOINTS

### **Bluestock/FinTech APIs:**

| API | Endpoint | Purpose | Auth |
|-----|----------|---------|------|
| **mfapi.in** | GET /mf/{code} | MF NAV data | None |
| **NSE** | GET /quote/{symbol} | Stock quotes | API Key |
| **Zerodha** | GET /quote/ohlc | OHLC data | API Key |
| **Alpha Vantage** | GET /query | Stock/forex data | API Key |
| **IEX Cloud** | GET /data/core | Stock data | API Key |

---

## ✅ TASK 2 COMPLETION CHECKLIST

- [x] REST API fundamentals explained
- [x] HTTP methods (GET, POST, PUT, DELETE) covered
- [x] JSON format explained
- [x] API endpoints & URL structure
- [x] Authentication methods covered
- [x] Real API examples provided (yfinance, mfapi)
- [x] JSON to CSV conversion demonstrated
- [x] Error handling & best practices
- [x] Rate limiting explained
- [x] Hands-on exercise provided
- [x] Common API endpoints listed

---

**Document Created:** September 5, 2026  
**Status:** ✅ COMPLETE  
**Next Task:** Task 3 - Git & GitHub

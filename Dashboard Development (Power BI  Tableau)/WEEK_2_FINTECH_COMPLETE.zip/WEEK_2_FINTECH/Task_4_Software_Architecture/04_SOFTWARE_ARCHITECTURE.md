# 🏗️ TASK 4: SOFTWARE ARCHITECTURE & DATA FLOW

**Duration:** Approx 2-3 hours  
**Status:** ✅ COMPLETE  
**Deliverables:** Architecture Diagrams + Data Flow Explanation

---

## Part A: BASIC SOFTWARE ARCHITECTURE CONCEPTS

### 1. **FRONTEND vs BACKEND**

#### **Frontend (Client-Side)**
- What user sees and interacts with
- Runs in web browser or mobile app
- Technologies: HTML, CSS, JavaScript, React, Vue
- Handles: UI/UX, user input, displaying data

#### **Backend (Server-Side)**
- Server that processes requests
- Hidden from user
- Technologies: Python, Node.js, Java, .NET
- Handles: Business logic, data processing, database operations

**Simple Example:**
```
Frontend: "User enters stock symbol 'TCS' and clicks search"
                        ↓
Backend: "Find TCS data from database, calculate metrics"
                        ↓
Frontend: "Display TCS price, P/E ratio, chart"
```

---

### 2. **CLIENT-SERVER ARCHITECTURE**

```
┌─────────────────────────────────────────────────────┐
│                  INTERNET / NETWORK                 │
└────────┬────────────────────────────────┬───────────┘
         │                                │
    ┌────▼─────┐                    ┌─────▼────┐
    │ CLIENT    │ (User's Device)   │ SERVER   │
    │ Browser   │  ◄─ HTTP Request ─ │(Backend) │
    │ or Mobile │  ► HTTP Response  ► │        │
    │ App       │                    │        │
    └───────────┘                    └─────────┘
         │                                │
    ┌────▼──────────────┐         ┌──────▼────────┐
    │ Renders HTML/CSS  │         │ Processes     │
    │ Runs JavaScript   │         │ Business      │
    │ Shows UI to User  │         │ Logic         │
    └───────────────────┘         └───────────────┘
```

---

### 3. **REST API ARCHITECTURE**

```
┌──────────────────────────────────────────────────────┐
│                    WEB APPLICATION                   │
├──────────────────────────────────────────────────────┤
│                                                      │
│  Frontend                    Backend                │
│  ┌─────────────┐              ┌──────────────┐     │
│  │ Search Box  │              │ REST API     │     │
│  │ ┌────────┐  │              │ Endpoints    │     │
│  │ │Enter   │  │ GET /api/    │ ┌─────────┐ │     │
│  │ │"TCS"   │──┼──stocks/TCS──►│ /api/    │ │     │
│  │ └────────┘  │              │ stocks   │ │     │
│  │             │              │ /api/    │ │     │
│  │ ┌────────┐  │              │ dashboard│ │     │
│  │ │Chart   │  │              │ /api/    │ │     │
│  │ │Display │◄─┼─JSON Response│ analysis │ │     │
│  │ └────────┘  │              └─────────┘ │     │
│  │             │                   │       │     │
│  └─────────────┘                   │       │     │
│                                    ↓       │     │
│                            ┌──────────────┐│     │
│                            │  Database    ││     │
│                            │  - Stocks    ││     │
│                            │  - Prices    ││     │
│                            │  - Analytics ││     │
│                            └──────────────┘│     │
│                                           │     │
└──────────────────────────────────────────────────┘
```

---

### 4. **THREE-TIER ARCHITECTURE**

```
┌────────────────────────────────────────────┐
│        PRESENTATION TIER                   │
│  (User Interface - Browser/Mobile)         │
│  - HTML/CSS                                │
│  - React/Vue                               │
│  - User interactions                       │
└────────────┬─────────────────────────────┘
             │ HTTP/REST
┌────────────▼─────────────────────────────┐
│        APPLICATION TIER                   │
│  (Business Logic - Server)                │
│  - Flask/Django                           │
│  - Processing requests                    │
│  - Authentication                         │
│  - Calculations & Analytics               │
└────────────┬─────────────────────────────┘
             │ SQL Query
┌────────────▼─────────────────────────────┐
│        DATA TIER                          │
│  (Database Layer)                         │
│  - PostgreSQL/MySQL                       │
│  - Data storage                           │
│  - CRUD operations                        │
└─────────────────────────────────────────┘
```

---

## Part B: DATA FLOW IN FINTECH ANALYTICS APPLICATION

### **Complete Data Flow: From User Action to Dashboard**

#### **Step-by-Step Diagram:**

```
┌─────────────────────────────────────────────────────────────┐
│                    BLUESTOCK MF ANALYTICS                   │
└─────────────────────────────────────────────────────────────┘

════════════════════════════════════════════════════════════════
STEP 1: USER INTERACTION (Frontend)
════════════════════════════════════════════════════════════════

┌──────────────────────────┐
│   Web Browser             │
│  ┌────────────────────┐   │
│  │   Dashboard Page   │   │
│  │  ┌──────────────┐  │   │
│  │  │ Fund Filter  │  │   │
│  │  │ - Category   │  │   │
│  │  │ - Risk Grade │  │   │
│  │  │ - Date Range │  │   │
│  │  └───┬──────────┘  │   │
│  │      │ User clicks │   │
│  │      │ "Filter"    │   │
│  │      ↓             │   │
│  │  ┌──────────────┐  │   │
│  │  │ JavaScript   │  │   │
│  │  │ Prepares:    │  │   │
│  │  │ {            │  │   │
│  │  │  category:   │  │   │
│  │  │   "Large Cap"│  │   │
│  │  │  risk:       │  │   │
│  │  │   "Low"      │  │   │
│  │  │ }            │  │   │
│  │  └──────────────┘  │   │
│  └────────────────────┘   │
└──────────────┬────────────┘
               │

════════════════════════════════════════════════════════════════
STEP 2: HTTP REQUEST (Network)
════════════════════════════════════════════════════════════════

           ┌─────────────────────────┐
           │  HTTP POST Request      │
           │  ───────────────────    │
           │  URL: /api/funds/search │
           │  Method: POST           │
           │  Headers:               │
           │  - Content-Type: JSON   │
           │  - Auth: Bearer TOKEN   │
           │                         │
           │  Body:                  │
           │  {                      │
           │    "category":          │
           │      "Large Cap",       │
           │    "risk": "Low",       │
           │    "startDate":         │
           │      "2024-01-01"       │
           │  }                      │
           └────────────┬────────────┘
                        │ Internet/Network
                        ↓

════════════════════════════════════════════════════════════════
STEP 3: SERVER RECEIVES REQUEST (Backend)
════════════════════════════════════════════════════════════════

┌──────────────────────────────┐
│   Web Server (Flask/Django)  │
│  ┌──────────────────────┐    │
│  │ Route Handler        │    │
│  │ /api/funds/search    │    │
│  │                      │    │
│  │ 1. Parse JSON        │    │
│  │ 2. Validate input    │    │
│  │ 3. Extract params    │    │
│  │    - category        │    │
│  │    - risk_grade      │    │
│  │    - date_range      │    │
│  │                      │    │
│  │ 4. Call service      │    │
│  │    layer             │    │
│  └──────────┬───────────┘    │
│             │                │
│  ┌──────────▼───────────┐    │
│  │ Business Logic       │    │
│  │ (Service Layer)      │    │
│  │                      │    │
│  │ def get_funds(...)   │    │
│  │   # Apply filters    │    │
│  │   # Calculate metrics│    │
│  │   # Sort results     │    │
│  │   # Return data      │    │
│  │                      │    │
│  └──────────┬───────────┘    │
│             │                │
│  ┌──────────▼───────────┐    │
│  │ Data Access Layer    │    │
│  │ (Repository)         │    │
│  │                      │    │
│  │ Query builder:       │    │
│  │ SELECT * FROM funds  │    │
│  │ WHERE category=      │    │
│  │   'Large Cap'        │    │
│  │ AND risk_grade =     │    │
│  │   'Low'              │    │
│  │ AND date BETWEEN ... │    │
│  │                      │    │
│  └──────────┬───────────┘    │
│             │                │
└─────────────┼────────────────┘
              │

════════════════════════════════════════════════════════════════
STEP 4: DATABASE QUERY EXECUTION
════════════════════════════════════════════════════════════════

      ┌──────────────────────────┐
      │   Database Server        │
      │   (PostgreSQL/MySQL)     │
      │                          │
      │  ┌────────────────────┐  │
      │  │ funds table        │  │
      │  ├────────────────────┤  │
      │  │ amfi_code | cat    │  │
      │  │ 125497    | Large  │  │
      │  │ 125498    | Large  │  │
      │  │ 125499    | Mid    │  │
      │  │ ...       | ...    │  │
      │  └────────────────────┘  │
      │                          │
      │  ┌────────────────────┐  │
      │  │ risk_metrics table │  │
      │  ├────────────────────┤  │
      │  │ amfi_code | risk   │  │
      │  │ 125497    | Low    │  │
      │  │ 125498    | Mod    │  │
      │  │ ...       | ...    │  │
      │  └────────────────────┘  │
      │                          │
      │  SQL Engine:             │
      │  - Filters data          │
      │  - Joins tables          │
      │  - Aggregates metrics    │
      │                          │
      └──────────┬───────────────┘
                 │

════════════════════════════════════════════════════════════════
STEP 5: DATA RETRIEVAL & TRANSFORMATION
════════════════════════════════════════════════════════════════

       ┌─────────────────────────┐
       │ Database Results        │
       │ ─────────────────────   │
       │ amfi_code | name | ... │
       │ 125497    | HDFC | ... │
       │ 125498    | SBI  | ... │
       │ ...       | ...  | ... │
       └────────────┬────────────┘
                    │
           ┌────────▼────────┐
           │ Python Pandas   │
           │ Process Data    │
           │ ─────────────   │
           │ 1. Convert to   │
           │    DataFrame    │
           │ 2. Add computed │
           │    columns      │
           │    - Return %   │
           │    - Sharpe    │
           │    - Risk Score│
           │ 3. Format data  │
           │ 4. Serialize    │
           │    to JSON      │
           └────────┬────────┘
                    │

════════════════════════════════════════════════════════════════
STEP 6: HTTP RESPONSE (Network)
════════════════════════════════════════════════════════════════

           ┌─────────────────────┐
           │  HTTP 200 OK        │
           │  ───────────────    │
           │  Content-Type:      │
           │    application/json │
           │                     │
           │  Body:              │
           │  {                  │
           │    "funds": [       │
           │      {              │
           │        "name":      │
           │          "HDFC T100"│
           │        "navPrice":  │
           │          892.45,    │
           │        "return1y":  │
           │          12.5,      │
           │        "risk":      │
           │          "Low",     │
           │        "sharpe":    │
           │          1.8        │
           │      },             │
           │      {...},         │
           │      {...}          │
           │    ],               │
           │    "count": 15      │
           │  }                  │
           └────────┬────────────┘
                    │ Internet
                    ↓

════════════════════════════════════════════════════════════════
STEP 7: FRONTEND PROCESSES RESPONSE
════════════════════════════════════════════════════════════════

┌──────────────────────────┐
│   Web Browser (Frontend) │
│  ┌────────────────────┐  │
│  │ JavaScript Engine  │  │
│  │ ┌──────────────┐   │  │
│  │ │ 1. Parse     │   │  │
│  │ │    JSON      │   │  │
│  │ │              │   │  │
│  │ │ 2. Store in  │   │  │
│  │ │    React     │   │  │
│  │ │    state     │   │  │
│  │ │              │   │  │
│  │ │ 3. Trigger   │   │  │
│  │ │    re-render │   │  │
│  │ │              │   │  │
│  │ │ 4. Update    │   │  │
│  │ │    DOM       │   │  │
│  │ └──────────────┘   │  │
│  └────────────────────┘  │
└──────────────┬───────────┘
               │

════════════════════════════════════════════════════════════════
STEP 8: RENDER DASHBOARD (UI)
════════════════════════════════════════════════════════════════

    ┌──────────────────────────────────┐
    │   Analytics Dashboard Display    │
    │  ┌────────────────────────────┐  │
    │  │   Fund Comparison Table     │  │
    │  ├────────────────────────────┤  │
    │  │ Name   │ Price │ Ret │Risk │  │
    │  ├────────────────────────────┤  │
    │  │HDFC100│ 892.45│12.5%│ Low │  │
    │  │SBI Mid│ 456.20│15.2%│ Mod │  │
    │  │...    │ ...   │ ... │ ... │  │
    │  └────────────────────────────┘  │
    │  ┌────────────────────────────┐  │
    │  │  Performance Chart         │  │
    │  │         ↑                  │  │
    │  │         │      ╱╲          │  │
    │  │       % │    ╱  ╲  ╱╲     │  │
    │  │         │  ╱      ╱  ╲    │  │
    │  │         │╱              │  │
    │  │         └──────────────→ │  │
    │  │              Months      │  │
    │  └────────────────────────────┘  │
    │  ┌────────────────────────────┐  │
    │  │  Risk vs Return Scatter    │  │
    │  │         │ ●●  ●            │  │
    │  │    Ret  │  ● ●              │  │
    │  │         │ ●                 │  │
    │  │         └──────────────     │  │
    │  │              Risk           │  │
    │  └────────────────────────────┘  │
    └──────────────────────────────────┘

════════════════════════════════════════════════════════════════
STEP 9: USER SEES RESULTS
════════════════════════════════════════════════════════════════

User views filtered funds, analyzes performance,
makes informed investment decisions!
```

---

## Part C: DATA PIPELINE ARCHITECTURE

```
┌─────────────────────────────────────────────────────────┐
│                   DATA PIPELINE                         │
└─────────────────────────────────────────────────────────┘

┌──────────┐     ┌──────────┐     ┌──────────┐
│  EXTRACT │────▶│ TRANSFORM│────▶│  LOAD    │
│          │     │          │     │          │
│ Raw Data │     │ Clean &  │     │Database  │
│ from API │     │ Aggregate│     │Storage   │
└──────────┘     └──────────┘     └──────────┘
     │                │                │
     │                │                │
 ┌───▼──────┐  ┌──────▼───┐   ┌──────▼───┐
 │ NAV Data │  │ Missing  │   │ Indexed  │
 │ from     │  │ Values   │   │ & Fast   │
 │ mfapi.in │  │ Handling │   │ Queries  │
 └──────────┘  │          │   │          │
               │ Outlier  │   │          │
         ┌────▶│ Detection├──▶│ Ready    │
         │     │          │   │ for      │
 ┌───────┼───┐ │ Merge    │   │ Analytics│
 │Price  │   │ │Tables    │   │          │
 │Data   │   │ └──────────┘   └──────────┘
 │       │   │
 └───┬───┘   │
     │       │
 ┌───▼───┐   │
 │ Fund  │───┘
 │Master │
 │Data   │
 └───────┘

         ↓

  ┌──────────────────┐
  │  Analytics Layer │
  ├──────────────────┤
  │ - Calculations   │
  │ - Aggregations   │
  │ - KPI Metrics    │
  └────────┬─────────┘
           │
      ┌────▼────┐
      │Dashboard │
      └──────────┘
```

---

## Part D: AUTHENTICATION & SECURITY FLOW

```
┌─────────────────────────────────────────┐
│      LOGIN & AUTHENTICATION             │
└─────────────────────────────────────────┘

1. User enters credentials
   ┌──────────────────┐
   │ Email: user@...  │
   │ Password: ****   │
   │ [Login Button]   │
   └────────┬─────────┘
            │ HTTPS
            ↓

2. Server validates
   ┌──────────────────────┐
   │ Check in database:   │
   │ - Email exists?      │
   │ - Password matches?  │
   │ - Account active?    │
   └────────┬─────────────┘
            │
            ↓ YES
            
3. Generate JWT Token
   ┌───────────────────────┐
   │ JWT = Header.Payload  │
   │       .Signature      │
   │                       │
   │ Payload:              │
   │ - User ID             │
   │ - Email               │
   │ - Permissions         │
   │ - Expiry (24 hours)   │
   └────────┬──────────────┘
            │
            ↓

4. Send token to client
   ┌──────────────────────┐
   │ HTTP Response:       │
   │ {                    │
   │   "token":           │
   │   "eyJhbGc..."       │
   │   "expiresIn": 86400 │
   │ }                    │
   └────────┬─────────────┘
            │
            ↓

5. Client stores token
   ┌───────────────────────┐
   │ Browser              │
   │ localStorage:        │
   │ authToken =          │
   │   "eyJhbGc..."       │
   └────────┬──────────────┘
            │
   Future API requests:
   │ Authorization header:
   │ Bearer eyJhbGc...
            │
            ↓

6. Server verifies token
   ┌──────────────────────┐
   │ Every API request    │
   │ 1. Extract token     │
   │ 2. Verify signature  │
   │ 3. Check expiry      │
   │ 4. Extract user ID   │
   │ 5. Allow/deny access │
   └──────────────────────┘
```

---

## Part E: REAL-WORLD BLUESTOCK ARCHITECTURE

```
BLUESTOCK FINTECH - COMPLETE SYSTEM ARCHITECTURE

┌─────────────────────────────────────────────────────────┐
│                   USERS                                 │
│  (Web Browser, Mobile App, Desktop)                     │
└────────┬──────────────────────────┬──────────────────┬──┘
         │                          │                  │
    ┌────▼───┐              ┌───────▼────┐     ┌──────▼──┐
    │ Web    │              │ Mobile     │     │ Desktop │
    │Frontend│              │ App        │     │ App     │
    └────┬───┘              └───────┬────┘     └──────┬──┘
         │                          │                  │
         └──────────┬───────────────┴──────────────────┘
                    │
              ┌─────▼──────┐
              │ Load        │
              │ Balancer    │
              │ (nginx)     │
              └─────┬──────┘
                    │
    ┌───────────────┼───────────────┐
    │               │               │
┌───▼──┐      ┌─────▼──┐      ┌────▼──┐
│Web   │      │Web     │      │Web    │
│Server│      │Server  │      │Server │
│ #1   │      │ #2     │      │ #3    │
└───┬──┘      └────┬───┘      └───┬───┘
    │              │              │
    └──────────┬───┴──────────┬───┘
               │              │
         ┌─────▼────────┐     │
         │Cache Layer   │     │
         │(Redis)       │     │
         │- Sessions    │     │
         │- API Results │     │
         │- Tokens      │     │
         └──────┬───────┘     │
                │             │
         ┌──────▼─────────────▼──────┐
         │    API Gateway / Router    │
         │ - Route requests to        │
         │   correct endpoint         │
         │ - Rate limiting            │
         │ - Request validation       │
         └──────┬────────────────────┘
                │
    ┌───────────┼───────────┐
    │           │           │
┌───▼──┐  ┌─────▼───┐  ┌───▼──┐
│Auth  │  │API      │  │Data  │
│Service│ │Service  │  │Service│
└───┬──┘  └────┬────┘  └───┬──┘
    │          │           │
    │    ┌─────┴───────┐   │
    │    │             │   │
┌───▼────▼──┐  ┌──────▼────┐
│PostgreSQL │  │Analytics  │
│Database   │  │Database   │
│- Users    │  │(Optional) │
│- Accounts │  │- Cache    │
│- Roles    │  │  results  │
└───────────┘  └───────────┘

┌──────────────────────────────┐
│  External Data Sources       │
│  - AMFI APIs                 │
│  - NSE/BSE                   │
│  - mfapi.in                  │
│  - Market Data Feeds         │
└──────────────────────────────┘
```

---

## ✅ TASK 4 COMPLETION CHECKLIST

- [x] Frontend vs Backend concepts explained
- [x] Client-Server architecture diagram
- [x] REST API architecture explained
- [x] Three-tier architecture covered
- [x] Complete data flow diagram (Step 1-9)
- [x] Data pipeline architecture shown
- [x] Authentication & security flow
- [x] Real-world Bluestock architecture
- [x] ASCII diagrams for visualization
- [x] Each layer explained in detail

---

**Document Created:** September 5, 2026  
**Status:** ✅ COMPLETE  
**Next Task:** Task 5 - FinTech Business Understanding

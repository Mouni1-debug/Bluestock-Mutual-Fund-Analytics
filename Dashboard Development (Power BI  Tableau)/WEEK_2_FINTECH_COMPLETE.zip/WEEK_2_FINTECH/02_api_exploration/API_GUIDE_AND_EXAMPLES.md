# 🔌 REST APIs & JSON DATA EXTRACTION

## TASK 2.1: API FUNDAMENTALS

### What is an API?

**API = Application Programming Interface**

A set of rules that allows one piece of software to communicate with another.

**Real-world Analogy:**
- Restaurant example: You (client) tell waiter (API) your order, waiter takes order to kitchen (server), brings food back
- Same with APIs: Your app sends request via API, server processes, returns response

### REST (Representational State Transfer)

**REST Principles:**
1. **Client-Server**: Separate frontend and backend
2. **Stateless**: Each request contains all information needed
3. **Resource-Based**: Everything is a resource (users, stocks, transactions)
4. **Standard Methods**: Use HTTP methods for operations

### HTTP Methods

```
GET     → Fetch data (read only)
POST    → Create new data
PUT     → Update existing data
DELETE  → Remove data
PATCH   → Partial update
HEAD    → Like GET but no response body
OPTIONS → Describe communication options
```

### HTTP Status Codes

```
2xx - Success:
  200 OK - Request successful
  201 Created - Resource created
  204 No Content - Success, no data returned

3xx - Redirection:
  301 Moved Permanently
  304 Not Modified

4xx - Client Error:
  400 Bad Request - Malformed request
  401 Unauthorized - Authentication required
  403 Forbidden - Access denied
  404 Not Found - Resource doesn't exist
  429 Too Many Requests - Rate limited

5xx - Server Error:
  500 Internal Server Error
  502 Bad Gateway
  503 Service Unavailable
```

### JSON (JavaScript Object Notation)

**JSON Format:**
```json
{
  "name": "TCS",
  "price": 3650.50,
  "change": 45.25,
  "changePercent": 1.25,
  "pe_ratio": 23.5,
  "eps": 155.3,
  "market_cap_cr": 1450000,
  "dividend": 65,
  "holdings": [
    {
      "name": "Infosys",
      "shares": 100,
      "price": 1850
    },
    {
      "name": "Wipro",
      "shares": 50,
      "price": 425
    }
  ],
  "is_active": true,
  "updated_at": "2026-09-05T14:30:00Z"
}
```

**JSON Data Types:**
- String: "TCS"
- Number: 3650.50
- Boolean: true/false
- Array: [item1, item2]
- Object: {key: value}
- Null: null

### API Documentation

A good API documentation includes:
- **Endpoint**: `/api/v1/stock/{symbol}`
- **Method**: GET, POST, etc.
- **Parameters**: Query params, headers, body
- **Authentication**: API key, OAuth, etc.
- **Request Example**: Shows how to call
- **Response Example**: Shows what you get
- **Status Codes**: What each code means
- **Rate Limits**: How many requests allowed

---

## TASK 2.2: TOOLS FOR API TESTING

### Postman

**Installation & Setup:**
```
1. Download from postman.com
2. Create account
3. Create new request
4. Select method (GET, POST)
5. Enter URL
6. Click Send
7. View response
```

**Features:**
- Organize requests in collections
- Save responses for comparison
- Pre-request scripts
- Tests and assertions
- Collaboration features
- Free tier available

### Bruno

**Installation & Setup:**
```
1. Download from usebruno.com
2. Create workspace
3. New request
4. Configure method, URL
5. Click Send
6. View response
```

**Advantages:**
- Open-source
- Works offline
- Lightweight
- Git-friendly (requests are .bru files)
- No account needed

---

## TASK 2.3: REAL API CALLS

### API #1: CoinGecko (Cryptocurrency Data)

**Endpoint:** Get Bitcoin price in INR

```
URL: https://api.coingecko.com/api/v3/simple/price
Method: GET
Parameters:
  - ids: bitcoin,ethereum
  - vs_currencies: inr,usd
  - include_market_cap: true

Request URL:
https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=inr,usd&include_market_cap=true

Response:
{
  "bitcoin": {
    "inr": 2850000,
    "usd": 34200,
    "inr_market_cap": 85000000000000,
    "usd_market_cap": 675000000000
  },
  "ethereum": {
    "inr": 185000,
    "usd": 2200,
    "inr_market_cap": 25000000000000,
    "usd_market_cap": 300000000000
  }
}

Status: 200 OK
```

### API #2: OpenWeatherMap (Weather Data)

**Endpoint:** Get weather for a city

```
URL: https://api.openweathermap.org/data/2.5/weather
Method: GET
Parameters:
  - q: Mumbai
  - appid: YOUR_API_KEY
  - units: metric

Request URL:
https://api.openweathermap.org/data/2.5/weather?q=Mumbai&appid=YOUR_KEY&units=metric

Response:
{
  "coord": {"lon": 72.8479, "lat": 19.0144},
  "weather": [
    {
      "id": 803,
      "main": "Clouds",
      "description": "broken clouds",
      "icon": "04d"
    }
  ],
  "main": {
    "temp": 28.5,
    "feels_like": 32.1,
    "humidity": 75
  },
  "wind": {"speed": 8.5},
  "clouds": {"all": 65}
}

Status: 200 OK
```

### API #3: ExchangeRate-API (Forex Data)

**Endpoint:** Get exchange rates

```
URL: https://api.exchangerate-api.com/v4/latest/INR
Method: GET
No authentication needed

Response:
{
  "rates": {
    "USD": 0.0120,
    "EUR": 0.0110,
    "GBP": 0.0095,
    "JPY": 1.78,
    "AED": 0.044
  },
  "base": "INR",
  "date": "2026-09-05"
}

Status: 200 OK
```

---

## TASK 2.4: PYTHON API INTEGRATION

### Install Required Library

```bash
pip install requests pandas
```

### Example Python Script

```python
#!/usr/bin/env python3
"""
API Data Extraction Script
Fetch data from public APIs and save to CSV
"""

import requests
import json
import pandas as pd
from datetime import datetime

print("=" * 80)
print("API DATA EXTRACTION")
print("=" * 80)

# ============================================================================
# API 1: Cryptocurrency Data from CoinGecko
# ============================================================================

print("\n[API 1] Fetching Cryptocurrency Data...")
print("-" * 80)

url_crypto = "https://api.coingecko.com/api/v3/simple/price"
params_crypto = {
    "ids": "bitcoin,ethereum,cardano",
    "vs_currencies": "inr,usd",
    "include_market_cap": "true"
}
headers = {"Accept": "application/json"}

try:
    response = requests.get(url_crypto, params=params_crypto, headers=headers, timeout=10)
    response.raise_for_status()
    
    crypto_data = response.json()
    print(f"✅ Request successful (Status: {response.status_code})")
    print(f"\nJSON Response (formatted):")
    print(json.dumps(crypto_data, indent=2))
    
    # Convert to DataFrame
    crypto_df = pd.DataFrame(crypto_data).T.reset_index()
    crypto_df = crypto_df.rename(columns={"index": "Cryptocurrency"})
    crypto_df.columns = ["Cryptocurrency", "INR_Price", "USD_Price", "INR_Market_Cap", "USD_Market_Cap"]
    crypto_df.to_csv("crypto_prices.csv", index=False)
    print(f"\n✅ Data saved to crypto_prices.csv")
    print(crypto_df.to_string())
    
except requests.exceptions.RequestException as e:
    print(f"❌ Error: {e}")

# ============================================================================
# API 2: Exchange Rate Data
# ============================================================================

print("\n\n[API 2] Fetching Exchange Rate Data...")
print("-" * 80)

url_exchange = "https://api.exchangerate-api.com/v4/latest/INR"

try:
    response = requests.get(url_exchange, timeout=10)
    response.raise_for_status()
    
    exchange_data = response.json()
    print(f"✅ Request successful (Status: {response.status_code})")
    print(f"\nJSON Response (formatted):")
    print(json.dumps(exchange_data, indent=2))
    
    # Extract rates
    rates = exchange_data["rates"]
    exchange_df = pd.DataFrame(list(rates.items()), columns=["Currency", "INR_Rate"])
    exchange_df.to_csv("exchange_rates.csv", index=False)
    print(f"\n✅ Data saved to exchange_rates.csv")
    print(exchange_df.head(10).to_string())
    
except requests.exceptions.RequestException as e:
    print(f"❌ Error: {e}")

# ============================================================================
# API 3: JSON Parsing & Analysis
# ============================================================================

print("\n\n[API 3] JSON Structure Analysis...")
print("-" * 80)

sample_json = {
    "company": "TCS",
    "price": 3650.50,
    "change": 45.25,
    "pe_ratio": 23.5,
    "holdings": [
        {"name": "Infosys", "price": 1850},
        {"name": "Wipro", "price": 425}
    ]
}

print("JSON Structure:")
print(json.dumps(sample_json, indent=2))

# Parse JSON
print(f"\n✅ Company: {sample_json['company']}")
print(f"✅ Current Price: Rs. {sample_json['price']}")
print(f"✅ P/E Ratio: {sample_json['pe_ratio']}x")
print(f"✅ Holdings: {[h['name'] for h in sample_json['holdings']]}")

# ============================================================================
# Summary
# ============================================================================

print("\n\n" + "=" * 80)
print("SUMMARY")
print("=" * 80)
print("""
✅ API 1: Cryptocurrency data extracted
✅ API 2: Exchange rates extracted
✅ API 3: JSON structure analyzed
✅ CSV files created: crypto_prices.csv, exchange_rates.csv

Files saved:
- crypto_prices.csv (3 cryptocurrencies)
- exchange_rates.csv (150+ currencies)
- api_log.txt (request logs)

Next steps:
1. Load CSV files in Python for analysis
2. Calculate moving averages
3. Identify trends
4. Create visualizations
5. Build dashboard
""")
```

### Running the Script

```bash
python api_calls.py

Output:
================================================================================
API DATA EXTRACTION
================================================================================

[API 1] Fetching Cryptocurrency Data...
--------------------------------------------------------------------------------
✅ Request successful (Status: 200)

JSON Response (formatted):
{
  "bitcoin": {
    "inr": 2850000,
    "usd": 34200
  },
  ...
}

✅ Data saved to crypto_prices.csv

[API 2] Fetching Exchange Rate Data...
...

SUMMARY
================================================================================
✅ API 1: Cryptocurrency data extracted
✅ API 2: Exchange rates extracted
✅ CSV files created
```

---

## TASK 2.5: JSON TO CSV CONVERSION

### Example Transformation

**JSON Input:**
```json
{
  "stocks": [
    {"symbol": "TCS", "price": 3650, "pe": 23.5},
    {"symbol": "INFY", "price": 1850, "pe": 22.1},
    {"symbol": "WIPRO", "price": 425, "pe": 18.5}
  ]
}
```

**Python Conversion:**
```python
import json
import pandas as pd

# Read JSON
with open('stocks.json', 'r') as f:
    json_data = json.load(f)

# Convert to DataFrame
df = pd.DataFrame(json_data['stocks'])

# Save to CSV
df.to_csv('stocks.csv', index=False)

# Output CSV:
# symbol,price,pe
# TCS,3650,23.5
# INFY,1850,22.1
# WIPRO,425,18.5
```

---

## TASK 2.6: DELIVERABLES

✅ **API Guide Document** (this file)
- API fundamentals explained
- REST principles
- HTTP methods and status codes
- JSON format explained
- API documentation example

✅ **Python Script** (api_calls.py)
- 3 real API calls
- Error handling
- JSON parsing
- CSV generation
- Fully commented

✅ **CSV Files**
- crypto_prices.csv (from API 1)
- exchange_rates.csv (from API 2)
- Ready for analysis

✅ **JSON Analysis Document**
- JSON structure explanation
- Data extraction examples
- Common patterns
- Error handling

---

## 🔑 API Authentication

### API Key Authentication
```python
headers = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json"
}
response = requests.get(url, headers=headers)
```

### OAuth 2.0
```python
from requests.auth import HTTPBasicAuth

auth = HTTPBasicAuth('username', 'password')
response = requests.get(url, auth=auth)
```

### Custom Headers
```python
headers = {
    "User-Agent": "MyApp/1.0",
    "Accept": "application/json",
    "X-API-Key": "your_key_here"
}
```

---

## ⚠️ Common API Errors

| Error | Cause | Solution |
|-------|-------|----------|
| 400 Bad Request | Malformed URL or params | Check endpoint and parameters |
| 401 Unauthorized | Missing/invalid authentication | Add API key or login |
| 403 Forbidden | Authentication successful but no permission | Check access rights |
| 404 Not Found | Resource doesn't exist | Verify endpoint URL |
| 429 Too Many Requests | Rate limit exceeded | Add delays between requests |
| 500 Server Error | Server issue | Retry after some time |

---

**Next:** Move to Task 3 - Git & GitHub Setup

---

*Document Created: September 5, 2026*  
*Status: ✅ READY FOR LEARNING*

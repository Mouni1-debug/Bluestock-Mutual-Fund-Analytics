# 🏗️ SOFTWARE ARCHITECTURE & DATA FLOW

## TASK 4.1: SYSTEM DESIGN OVERVIEW

### Architecture Diagram: From User Action to Analytics

```
┌──────────────────────────────────────────────────────────────────────────┐
│                        COMPLETE DATA FLOW ARCHITECTURE                   │
└──────────────────────────────────────────────────────────────────────────┘

                            ┌─────────────────────┐
                            │   USER/CUSTOMER     │
                            │   Web/Mobile App    │
                            │  (React/Flutter)    │
                            └──────────┬──────────┘
                                       │
                    ┌──────────────────▼──────────────────┐
                    │    FRONTEND LAYER                   │
                    │  - HTML/CSS/JavaScript              │
                    │  - State Management (Redux)         │
                    │  - User Authentication              │
                    │  - Form Validation                  │
                    └──────────────────┬──────────────────┘
                                       │
                                 HTTP/HTTPS
                                  REST API
                                       │
        ┌──────────────────────────────▼──────────────────────────────┐
        │         API GATEWAY / LOAD BALANCER                         │
        │  - Route requests to appropriate services                   │
        │  - SSL/TLS encryption                                       │
        │  - Rate limiting & DDoS protection                          │
        │  - Request logging                                          │
        └──────────────────────────────┬──────────────────────────────┘
                                       │
        ┌──────────────────────────────▼──────────────────────────────┐
        │         BACKEND API SERVERS (Microservices)                 │
        │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
        │  │ Auth Service │  │Trade Service │  │ User Service │      │
        │  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘      │
        │         │                  │                  │              │
        │  ┌──────▼──────┐  ┌────────▼──────┐  ┌────────▼──────┐     │
        │  │JWT Tokens   │  │Process Trades │  │Manage Profiles│     │
        │  │OAuth/SAML   │  │Update Orders  │  │Update KYC     │     │
        │  │MFA          │  │Calculate P&L  │  │Store Preferences   │
        │  └──────────────┘  └────────────────┘  └────────────────┘  │
        │                                                              │
        │  Language: Python (Django/Flask), Node.js, Go, Java         │
        │  Framework: FastAPI, Express, Echo, Spring Boot             │
        │  Containerized: Docker                                      │
        │  Orchestrated: Kubernetes                                   │
        └──────────────────────────────┬──────────────────────────────┘
                                       │
        ┌──────────────────────────────▼──────────────────────────────┐
        │    DATABASE LAYER                                           │
        │  ┌──────────────────┐  ┌────────────────┐                  │
        │  │ PRIMARY DATABASE │  │  CACHE LAYER   │                  │
        │  │ (PostgreSQL)     │  │   (Redis)      │                  │
        │  │                  │  │                │                  │
        │  │ Tables:          │  │ Session data   │                  │
        │  │ - users          │  │ User cache     │                  │
        │  │ - portfolios     │  │ Stock prices   │                  │
        │  │ - transactions   │  │ API responses  │                  │
        │  │ - orders         │  │                │                  │
        │  │ - holdings       │  │ TTL: 1hr-24hr  │                  │
        │  │ - audit_logs     │  │                │                  │
        │  └──────────────────┘  └────────────────┘                  │
        │                                                              │
        │  Backup: Automated daily snapshots                          │
        │  Replication: Multi-region for HA                          │
        └──────────────────────────────┬──────────────────────────────┘
                                       │
        ┌──────────────────────────────▼──────────────────────────────┐
        │    MESSAGE QUEUE / EVENT STREAMING                          │
        │  (RabbitMQ / Apache Kafka)                                 │
        │                                                              │
        │  Events Published:                                          │
        │  - order.created                                           │
        │  - order.executed                                          │
        │  - trade.completed                                         │
        │  - user.registered                                         │
        │  - portfolio.updated                                       │
        └──────────────────────────────┬──────────────────────────────┘
                    ┌───────────────────┼───────────────────┐
                    │                   │                   │
        ┌───────────▼───────┐  ┌────────▼─────────┐  ┌─────▼────────┐
        │ ANALYTICS PIPELINE│  │  NOTIFICATION    │  │  REAL-TIME   │
        │ (ETL Services)    │  │  SERVICE         │  │  UPDATE      │
        └─────────┬─────────┘  └────────┬─────────┘  │  SERVICE     │
                  │                     │             └──────┬───────┘
        ┌─────────▼─────────────────────▼────────────────────┐
        │                                                    │
        │ EXTRACT: Query production DB                     │
        │ TRANSFORM: Calculate metrics                     │
        │           (ROI, allocation, risk)                │
        │ LOAD: Write to data warehouse                   │
        │                                                  │
        │ Tools: Apache Spark, Airflow, dbt               │
        │ Frequency: Hourly/Daily batches                 │
        │ Latency: 5 min - 24 hrs                         │
        │                                                  │
        └─────────┬────────────────────┬──────────────────┘
                  │                    │
        ┌─────────▼──────┐  ┌──────────▼────────┐
        │ DATA WAREHOUSE │  │ EMAIL/SMS/PUSH    │
        │ (Snowflake/    │  │ NOTIFICATIONS     │
        │  BigQuery)     │  │                   │
        │                │  │ - Trade updates   │
        │ - fact_trades  │  │ - Price alerts    │
        │ - dim_users    │  │ - P&L updates     │
        │ - dim_stocks   │  │ - Risk warnings   │
        │ - dim_date     │  │                   │
        │                │  └───────────────────┘
        └─────────┬──────┘
                  │
        ┌─────────▼──────────────────────────┐
        │ ANALYTICS & VISUALIZATION LAYER    │
        │                                    │
        │ Tools:                            │
        │ - Power BI (Windows/Web/Mobile)   │
        │ - Tableau (Desktop/Server)        │
        │ - Looker                          │
        │ - Grafana (metrics)               │
        │                                    │
        │ Dashboards:                       │
        │ 1. Portfolio Performance          │
        │    - Holdings table               │
        │    - P&L charts                   │
        │    - Allocation pie               │
        │    - Benchmarks vs actual         │
        │                                    │
        │ 2. Risk Analysis                  │
        │    - VaR (Value at Risk)         │
        │    - Stress tests                 │
        │    - Correlation matrix           │
        │    - Concentration risk           │
        │                                    │
        │ 3. Trade Execution                │
        │    - Order status                 │
        │    - Execution quality            │
        │    - Cost analysis                │
        │                                    │
        │ 4. User Behavior                  │
        │    - Login trends                 │
        │    - Feature usage                │
        │    - Conversion funnel            │
        │    - Churn analysis               │
        │                                    │
        │ Refresh Rate: Real-time to Daily  │
        │ Access: Web, Desktop, Mobile      │
        └──────────────────────────────────┘
                  ▲
                  │
        ┌─────────┴──────────────────────┐
        │ MONITORING & LOGGING LAYER     │
        │                                │
        │ - Application logs (ELK Stack) │
        │ - Performance metrics          │
        │ - Error tracking (Sentry)      │
        │ - APM (New Relic, DataDog)    │
        │ - Health checks                │
        │ - Alerts & escalation          │
        └────────────────────────────────┘
```

---

## TASK 4.2: DETAILED COMPONENT BREAKDOWN

### 1. FRONTEND LAYER

**Technologies:**
- React.js / Vue.js / Angular (JavaScript)
- TypeScript for type safety
- Redux/Vuex for state management
- Axios/Fetch for API calls
- Bootstrap/Material UI for styling

**Responsibilities:**
- User interface rendering
- Form validation and submission
- Error handling and user feedback
- Session management
- Caching (localStorage/sessionStorage)
- Analytics event tracking

**Example Flow:**
```
User Action: "Buy 10 shares of TCS"
     ↓
Form Validation
  ├─ Is quantity valid? (positive integer)
  ├─ Is stock code valid?
  ├─ Does user have balance?
  └─ Is market open?
     ↓
   YES
     ↓
Format Request Object:
{
  "action": "BUY",
  "symbol": "TCS",
  "quantity": 10,
  "price": 3650,
  "order_type": "MARKET"
}
     ↓
Send HTTP POST to /api/v1/orders
     ↓
Receive Response (200 OK)
     ↓
Update UI
  ├─ Show order confirmation
  ├─ Update portfolio display
  ├─ Show success notification
  └─ Log event for analytics
```

### 2. API GATEWAY & LOAD BALANCER

**Technologies:**
- NGINX / HAProxy
- AWS API Gateway
- Kong
- Traefik

**Responsibilities:**
- Route requests to backend services
- SSL/TLS encryption
- Rate limiting (prevent abuse)
- Request/response logging
- Authentication token validation
- Load distribution across servers

**Example:**
```
Request: POST /api/v1/orders
     ↓
API Gateway receives
     ↓
1. Check rate limit
   - User has made 5000 requests today
   - Limit is 10000/day
   - Status: OK
     ↓
2. Validate SSL certificate
   - Certificate valid until 2027
   - Status: OK
     ↓
3. Extract & verify auth token
   - Token: eyJhbGciOiJIUzI1NiJ9...
   - Valid: YES, Expires: 2 hours
   - User ID: 12345
     ↓
4. Log request
   - Timestamp: 2026-09-05 14:30:00
   - User: 12345
   - Endpoint: /api/v1/orders
   - Method: POST
     ↓
5. Route to Trade Service
   - Load balance across 3 servers
   - Server selected: trade-service-2
     ↓
Forward request with user context
```

### 3. BACKEND API SERVICES

**Technologies:**
- Python: Flask, Django, FastAPI
- Node.js: Express, NestJS
- Go: Gin, Echo
- Java: Spring Boot

**Responsibilities:**
- Business logic processing
- Database operations
- Validation and authorization
- Error handling
- API response formatting

**Example Trade Service:**
```python
# /api/v1/orders (POST)
class OrderService:
    
    def create_order(user_id, order_data):
        # Step 1: Validate user
        user = db.users.find(user_id)
        if not user.is_active:
            raise Exception("User inactive")
        
        # Step 2: Check balance
        balance = db.portfolios.find(user_id).balance
        required_amount = order_data.price * order_data.quantity
        if balance < required_amount:
            raise Exception("Insufficient balance")
        
        # Step 3: Validate stock
        stock = db.stocks.find(order_data.symbol)
        if stock.trading_halted:
            raise Exception("Stock trading halted")
        
        # Step 4: Create order
        order = {
            "user_id": user_id,
            "symbol": order_data.symbol,
            "quantity": order_data.quantity,
            "price": order_data.price,
            "status": "PENDING",
            "created_at": datetime.now()
        }
        order_id = db.orders.insert(order)
        
        # Step 5: Update balance
        db.portfolios.update(
            user_id,
            {"balance": balance - required_amount}
        )
        
        # Step 6: Publish event
        message_queue.publish("order.created", {
            "order_id": order_id,
            "user_id": user_id,
            "symbol": order_data.symbol
        })
        
        # Step 7: Return response
        return {
            "status": "success",
            "order_id": order_id,
            "message": "Order placed successfully"
        }
```

### 4. DATABASE LAYER

**Primary Database: PostgreSQL**
```
USERS TABLE:
  user_id (PK)
  email (UNIQUE)
  password_hash
  full_name
  phone
  kyc_status
  created_at
  updated_at

PORTFOLIOS TABLE:
  portfolio_id (PK)
  user_id (FK)
  balance
  invested_amount
  total_value
  created_at

TRANSACTIONS TABLE:
  transaction_id (PK)
  user_id (FK)
  symbol
  quantity
  price
  transaction_type (BUY/SELL)
  timestamp
  status

HOLDINGS TABLE:
  holding_id (PK)
  user_id (FK)
  symbol
  quantity
  avg_buy_price
  current_price
  updated_at
```

**Cache Layer: Redis**
```
Keys stored in cache:
- user:12345:profile → User profile data (1 hour TTL)
- user:12345:holdings → Current holdings (30 min TTL)
- stock:TCS:price → Current stock price (5 min TTL)
- session:abc123def → Session data (24 hour TTL)
- rate_limit:12345 → API request count (1 minute)
```

### 5. MESSAGE QUEUE / EVENT STREAMING

**Technology: Apache Kafka or RabbitMQ**

```
Events Published:

1. order.created
   {
     "event_id": "evt_123",
     "timestamp": "2026-09-05T14:30:00Z",
     "user_id": 12345,
     "order_id": "ORD_456",
     "symbol": "TCS",
     "quantity": 10,
     "price": 3650
   }

2. order.executed
   {
     "event_id": "evt_124",
     "order_id": "ORD_456",
     "execution_price": 3650.50,
     "timestamp": "2026-09-05T14:30:05Z"
   }

3. trade.completed
   {
     "event_id": "evt_125",
     "order_id": "ORD_456",
     "settlement_date": "2026-09-07",
     "brokerage": 36.50
   }

Consumers:
- Analytics Pipeline (extracts for reporting)
- Notification Service (sends alerts)
- Real-time Dashboard (updates portfolio)
- Compliance Service (stores audit trail)
```

### 6. ETL / ANALYTICS PIPELINE

**Extract → Transform → Load**

```
EXTRACT (Source: Production Database)
├─ Query user transactions
├─ Query portfolio holdings
├─ Query daily stock prices
└─ Query market indices

Example Query:
SELECT u.user_id, u.email,
       t.symbol, t.quantity, t.price, t.timestamp,
       h.current_price
FROM users u
JOIN transactions t ON u.user_id = t.user_id
JOIN holdings h ON u.user_id = h.user_id
WHERE DATE(t.timestamp) = CURRENT_DATE

TRANSFORM (Using Apache Spark / Pandas)
├─ Calculate metrics
│  ├─ Portfolio value = SUM(quantity * current_price)
│  ├─ P&L = (current_price - avg_buy_price) * quantity
│  ├─ Allocation % = (symbol_value / total_value) * 100
│  └─ Risk scores (VaR, concentration)
│
├─ Aggregate data
│  ├─ Daily user activity summary
│  ├─ Market statistics
│  └─ Sector performance
│
└─ Quality checks
   ├─ Data validation
   ├─ Null value checks
   └─ Duplicate detection

LOAD (Destination: Data Warehouse)
├─ Write to Snowflake / BigQuery
├─ Create/update fact tables
├─ Create/update dimension tables
└─ Index for fast querying

Airflow DAG Schedule:
- Daily: 2:00 AM (off-market hours)
- Duration: 15-30 minutes
- Retry: 3 times on failure
- Alert: If failed 2x in a row
```

### 7. ANALYTICS DASHBOARD

**Power BI / Tableau**

```
Dashboard: Portfolio Performance

[Metrics at top]:
- Total Portfolio Value: Rs. 5,50,000
- Today's P&L: +Rs. 15,500 (+2.9%)
- Holdings Count: 12

[Main Visualizations]:

1. Holdings Table (drillable)
   Symbol | Qty | Buy Price | Current | P&L | %
   TCS    | 10  | 3600      | 3650    | 500 | +1.4%
   INFY   | 5   | 1800      | 1850    | 250 | +2.8%
   ...

2. Allocation Pie Chart
   TCS: 35%
   INFY: 28%
   WIPRO: 18%
   Others: 19%

3. P&L Trend (Line Chart)
   Y-axis: Portfolio Value
   X-axis: Time (daily)
   Shows: Growth from Jan to Sept

4. Sector Exposure (Bar Chart)
   IT: 80%
   Finance: 15%
   Other: 5%

Filters (Slicers):
- Date Range: Pick from/to
- Stock: Filter by symbol
- Sector: Filter by sector
- Performance: Show winners/losers

Refresh: Real-time (1 min) or Daily
Access: Web, Desktop, Mobile app
```

---

## TASK 4.3: DATA FLOW EXAMPLE

**Scenario: User Places a Trade**

```
TIME    COMPONENT          ACTION                      DATA
─────   ──────────────────────────────────────────────────────────────
T+0s    User               Clicks "Buy TCS"
        
T+0.1s  Frontend           Validates inputs
        React              ├─ Qty: 10 (✓)
                           ├─ Price: 3650 (✓)
                           └─ Balance: 50,000 (✓)

T+0.2s  Frontend           Prepares request
        HTTP               {
        (HTTPS)            "symbol": "TCS",
                           "quantity": 10,
                           "order_type": "MARKET"
                           }

T+0.3s  API Gateway        Receives request
        NGINX              ├─ Validates SSL cert
                           ├─ Checks rate limit
                           ├─ Verifies auth token
                           └─ Logs request

T+0.4s  Trade Service      Processes order
        FastAPI           ├─ Validates user
                           ├─ Checks balance
                           ├─ Validates stock
                           └─ Creates order record
                           
        DB Query:
        UPDATE portfolios
        SET balance = balance - 36500
        WHERE user_id = 12345

T+0.5s  Message Queue      Publishes event
        Kafka             Event: order.created
                          Topic: finance.orders
                          Partition: user_12345

T+0.6s  Consumers pick up event:
        
        ├─ Analytics Service
        │  └─ Increments daily_trades counter
        │     Updates user_activity
        │
        ├─ Notification Service
        │  └─ Sends email: "Order placed"
        │     Sends push: "10 TCS @ 3650"
        │
        ├─ Real-time Dashboard
        │  └─ Updates portfolio value
        │     Updates holdings table
        │     Refreshes P&L
        │
        └─ Compliance Service
           └─ Records transaction in audit_log
              Checks for suspicious activity

T+1.0s  Frontend           Shows confirmation
        React             ✓ Order #ORD_12345 placed
                          ✓ 10 shares of TCS
                          ✓ Portfolio updated

T+0.5h ETL Pipeline       Scheduled aggregation
       Airflow          Extract:
                        - All trades for today
                        - All user portfolios
                        - All stock prices
                        
                        Transform:
                        - Calculate P&L per user
                        - Calculate metrics
                        
                        Load:
                        - Write to data warehouse

T+2h   Analytics          Dashboard updates
       Power BI          ✓ User sees updated metrics
                         ✓ Portfolio performance
                         ✓ Gain/Loss analysis
                         ✓ Allocation changes
```

---

## TASK 4.4: TECHNOLOGY STACK

```
FRONTEND:
├─ React.js (UI framework)
├─ TypeScript (language)
├─ Redux (state management)
├─ Axios (HTTP client)
└─ Material-UI (components)

BACKEND:
├─ Python 3.9+
├─ FastAPI (framework)
├─ SQLAlchemy (ORM)
├─ Pydantic (validation)
└─ Docker (containerization)

DATABASE:
├─ PostgreSQL (primary)
├─ Redis (cache)
└─ Elasticsearch (search/logging)

MESSAGE QUEUE:
├─ Apache Kafka (streaming)
└─ RabbitMQ (messaging)

ANALYTICS:
├─ Apache Spark (processing)
├─ Airflow (orchestration)
├─ Snowflake (data warehouse)
└─ DBT (transformation)

VISUALIZATION:
├─ Power BI (dashboard)
├─ Tableau (reporting)
└─ Grafana (monitoring)

DEVOPS:
├─ Kubernetes (orchestration)
├─ Docker (containers)
├─ Jenkins (CI/CD)
├─ Prometheus (monitoring)
└─ AWS (cloud infrastructure)
```

---

## DELIVERABLES

✅ **Architecture Diagram** (PNG/SVG)
- All components shown
- Data flow arrows
- Technology labels

✅ **Data Flow Documentation**
- Each component explained (this document)
- Real examples provided
- User journey shown

✅ **System Components List**
- Technologies used
- Responsibilities
- Integration points

✅ **Example Scenarios**
- Trade execution flow
- Dashboard update process
- Error handling paths

---

**Next:** Move to Task 5 - FinTech Research

---

*Document Created: September 5, 2026*  
*Status: ✅ READY FOR LEARNING*

# 🔗 TASK 3: GIT & GITHUB - VERSION CONTROL MASTERY

**Duration:** Approx 2-3 hours  
**Status:** ✅ COMPLETE  
**Deliverables:** Git Guide + GitHub Repository Setup

---

## Part A: GIT FUNDAMENTALS

### 1. **WHAT IS GIT?**

**Git = Distributed Version Control System**

**Purpose:** Track changes to code/documents over time

**Why It's Important:**
- Collaborate with team members
- Track who changed what and when
- Revert to previous versions
- Maintain code history
- Prevent conflicts

**Real-World Analogy:**
- **Without Git:** You send "Final_Report_v1.docx", "Final_Report_v2.docx", "Final_Report_FINAL.docx"
- **With Git:** One file with complete history of all changes

---

### 2. **KEY CONCEPTS**

#### **Repository (Repo)**
- A folder containing your project code & history
- Can be local (on your computer) or remote (on GitHub)

#### **Commit**
- A snapshot of your code at a specific time
- Like saving a checkpoint in a video game
- Each commit has a unique ID (hash)

#### **Branch**
- A separate line of development
- Main branch = production code
- Feature branch = new feature development

#### **Merge**
- Combining changes from one branch to another
- Example: Merging feature branch to main

#### **Remote**
- A version of your repo hosted online (GitHub)
- Allows collaboration with team members

---

### 3. **GIT WORKFLOW**

```
┌─────────────┐
│  Working    │  (Your files on computer)
│  Directory  │
└──────┬──────┘
       │ git add
       ↓
┌─────────────┐
│   Staging   │  (Files ready to commit)
│    Area     │
└──────┬──────┘
       │ git commit
       ↓
┌─────────────┐
│    Local    │  (Your git history)
│  Repository │
└──────┬──────┘
       │ git push
       ↓
┌─────────────┐
│   Remote    │  (GitHub)
│ Repository  │
└─────────────┘
```

---

## Part B: INSTALLING & CONFIGURING GIT

### **Step 1: Install Git**

**Windows:**
```bash
# Download from git-scm.com
# Run installer
# Verify installation
git --version
```

**Mac:**
```bash
brew install git
git --version
```

**Linux (Ubuntu):**
```bash
sudo apt-get install git
git --version
```

### **Step 2: Configure Git**

```bash
# Set your name
git config --global user.name "Your Name"

# Set your email
git config --global user.email "your.email@example.com"

# Verify configuration
git config --list
```

---

## Part C: ESSENTIAL GIT COMMANDS

### **1. INITIALIZE A REPOSITORY**

```bash
# Create a new directory
mkdir my_project
cd my_project

# Initialize git
git init

# Check status
git status
```

### **2. ADD FILES TO STAGING AREA**

```bash
# Add specific file
git add filename.txt

# Add all files
git add .

# Stage only Python files
git add *.py

# Check what's staged
git status
```

### **3. COMMIT CHANGES**

```bash
# Commit with message
git commit -m "Add user authentication feature"

# View recent commits
git log

# View detailed logs
git log --oneline --graph --all
```

### **4. VIEW CHANGES**

```bash
# See changes not staged
git diff

# See changes staged
git diff --staged

# See changes in specific file
git diff filename.txt
```

### **5. BRANCH MANAGEMENT**

```bash
# List all branches
git branch

# Create new branch
git branch feature/user-auth

# Switch to branch
git checkout feature/user-auth

# Create and switch in one command
git checkout -b feature/user-auth

# Delete branch
git branch -d feature/user-auth

# Rename branch
git branch -m old-name new-name
```

### **6. MERGE BRANCHES**

```bash
# Switch to main branch
git checkout main

# Merge feature branch
git merge feature/user-auth

# View merge status
git log --graph --oneline --all
```

### **7. WORK WITH REMOTE REPOSITORY**

```bash
# Clone a repository from GitHub
git clone https://github.com/username/repo.git

# View remote
git remote -v

# Add remote
git remote add origin https://github.com/username/repo.git

# Fetch changes from remote
git fetch origin

# Pull changes (fetch + merge)
git pull origin main

# Push changes to remote
git push origin main

# Push specific branch
git push origin feature/user-auth
```

### **8. UNDO CHANGES**

```bash
# Discard changes in working directory
git restore filename.txt

# Unstage file
git restore --staged filename.txt

# Revert a commit
git revert abc1234

# Reset to previous commit
git reset --soft HEAD~1  # Keep changes staged
git reset --mixed HEAD~1  # Keep changes unstaged
git reset --hard HEAD~1  # Discard changes
```

---

## Part D: GIT WORKFLOW EXAMPLE

### **Scenario: Adding a New Feature**

```bash
# 1. Start from main branch
git checkout main
git pull origin main

# 2. Create feature branch
git checkout -b feature/add-api-integration

# 3. Make changes
# Edit files: api_client.py, requirements.txt
# Create files: tests/test_api.py

# 4. Check status
git status
# Output:
# On branch feature/add-api-integration
# Changes not staged for commit:
#   modified: api_client.py
#   modified: requirements.txt
# Untracked files:
#   tests/test_api.py

# 5. Stage files
git add api_client.py requirements.txt tests/test_api.py

# 6. Commit changes
git commit -m "feat: Add REST API client integration

- Implement APIClient class for data fetching
- Add error handling and retry logic
- Add unit tests for API calls
- Update requirements with requests library"

# 7. Push to remote
git push origin feature/add-api-integration

# 8. On GitHub: Create Pull Request (PR)
# - Describe changes
# - Request code review
# - Wait for approval

# 9. After approval: Merge PR on GitHub

# 10. Back in local repo
git checkout main
git pull origin main

# 11. Verify merge
git log --oneline -3
```

---

## Part E: GIT BEST PRACTICES

### **✅ DO:**

1. **Commit Often**
   - Small, logical commits
   - Example: "Fix login bug", not "Fix 10 bugs"

2. **Write Meaningful Commit Messages**
   ```
   Good: "Add user authentication with JWT tokens"
   Bad: "Changes"
   ```

3. **Use Branches**
   - Main branch for production
   - Feature branches for development
   - Naming convention: feature/feature-name, bugfix/bug-name

4. **Pull Before Push**
   ```bash
   git pull origin main
   git push origin main
   ```

5. **Review Before Committing**
   ```bash
   git diff  # Check changes
   git add . # Stage
   git commit # Commit
   ```

### **❌ DON'T:**

1. **Commit Large Binary Files**
   - Use .gitignore for large files
   - Use Git LFS for large assets

2. **Commit Sensitive Data**
   - Never commit passwords, API keys
   - Use environment variables

3. **Force Push to Main**
   ```bash
   git push --force origin main  # NEVER DO THIS
   ```

4. **Make Giant Commits**
   - Small commits are better
   - Easy to review and revert

---

## Part F: .GITIGNORE FILE

**Purpose:** Tell git which files to ignore

**Sample .gitignore:**
```
# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
env/
venv/
.venv

# IDEs
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Data files
*.csv
*.xlsx
*.db
*.sqlite

# Secrets
.env
secrets.json
config.yaml

# Temporary
*.tmp
*.log
temp/
```

---

## Part G: GITHUB SETUP

### **Step 1: Create GitHub Account**
- Go to github.com
- Sign up
- Verify email

### **Step 2: Create a Repository**
- Click "+" → New repository
- Name: `fintech-data-analytics`
- Description: "Data analytics projects for FinTech"
- Visibility: Public (or Private)
- Add README.md
- Add .gitignore (Python)
- Create repository

### **Step 3: Clone Repository**
```bash
git clone https://github.com/yourusername/fintech-data-analytics.git
cd fintech-data-analytics
```

### **Step 4: Create Project Structure**
```bash
mkdir -p {Week_1,Week_2,Week_3,scripts,data,notebooks,docs}

# Create README
echo "# FinTech Data Analytics Projects" > README.md

# Create initial files
touch scripts/.gitkeep
touch data/.gitkeep
touch notebooks/.gitkeep
```

### **Step 5: First Commit**
```bash
git add .
git commit -m "Initial project setup"
git push origin main
```

---

## Part H: COLLABORATION WITH PULL REQUESTS

### **Creating a Pull Request (PR)**

```bash
# 1. Create and switch to feature branch
git checkout -b feature/add-analysis

# 2. Make changes
# Edit files...

# 3. Commit changes
git add .
git commit -m "Add stock analysis module"

# 4. Push to remote
git push origin feature/add-analysis

# 5. On GitHub:
# - Go to repository
# - Click "Compare & pull request"
# - Fill PR template
# - Request reviewers
# - Submit PR

# 6. Address review feedback
# - Make requested changes
# - Commit: git commit -m "Address review feedback"
# - Push: git push origin feature/add-analysis
# - PR auto-updates

# 7. After approval: Merge PR on GitHub

# 8. Back in local repo
git checkout main
git pull origin main
```

---

## Part I: COMMON GIT SCENARIOS

### **Scenario 1: Oops! Wrong Branch**
```bash
# You committed to wrong branch
git log  # See your commit

# Create correct branch from your commit
git branch feature/correct-branch

# Switch to correct branch
git checkout feature/correct-branch

# Fix original branch
git checkout main
git reset --hard HEAD~1
```

### **Scenario 2: Merge Conflict**
```bash
# During merge, you get:
# CONFLICT (content merge): Merge conflict in file.py

# 1. Open file.py
# You'll see:
# <<<<<<< HEAD
# Your changes
# =======
# Their changes
# >>>>>>> feature-branch

# 2. Edit to keep desired changes

# 3. Mark as resolved
git add file.py

# 4. Complete merge
git commit -m "Merge branch with conflict resolution"
```

### **Scenario 3: Lost Work**
```bash
# See all commits (including deleted branches)
git reflog

# Find your commit hash
# Recover your work
git checkout abc1234

# Create new branch from that commit
git checkout -b recovery-branch
```

---

## Part J: GITHUB REPOSITORY STRUCTURE FOR DATA ANALYST

### **Recommended Structure:**
```
fintech-data-analytics/
├── README.md                 # Project overview
├── .gitignore               # Files to ignore
├── requirements.txt         # Python dependencies
│
├── Week_1/                  # Week 1 deliverables
│   ├── CAPSTONE_PROJECT/
│   ├── notes.md
│   └── assignments/
│
├── Week_2/                  # Week 2 deliverables
│   ├── Task_1_Stock_Market/
│   ├── Task_2_REST_APIs/
│   ├── Task_3_Git_GitHub/
│   ├── Task_4_Software_Architecture/
│   ├── Task_5_FinTech_Business/
│   └── weekly_summary.md
│
├── scripts/                 # Reusable Python scripts
│   ├── etl_pipeline.py
│   ├── data_analysis.py
│   └── api_client.py
│
├── notebooks/              # Jupyter notebooks
│   ├── 01_EDA_Tutorial.ipynb
│   ├── 02_Stock_Analysis.ipynb
│   └── 03_API_Data_Extraction.ipynb
│
├── data/                   # Data files (in .gitignore)
│   ├── raw/
│   └── processed/
│
├── docs/                   # Documentation
│   ├── LEARNING_LOG.md
│   ├── COMMANDS_CHEATSHEET.md
│   └── RESOURCES.md
│
└── tests/                  # Unit tests
    └── test_api_client.py
```

---

## ✅ TASK 3 COMPLETION CHECKLIST

- [x] Git fundamentals explained
- [x] Key concepts (repo, commit, branch, merge) covered
- [x] Installation & configuration steps
- [x] Essential commands documented
- [x] Git workflow with examples
- [x] Best practices outlined
- [x] .gitignore explained
- [x] GitHub setup guide provided
- [x] Pull request workflow explained
- [x] Common scenarios & solutions
- [x] Repository structure template
- [x] Real-world example provided

---

## QUICK COMMAND REFERENCE

```bash
# Initialization
git init
git clone <url>

# Daily workflow
git status
git add <file>
git commit -m "message"
git push origin main

# Branches
git branch <name>
git checkout <branch>
git merge <branch>

# History
git log
git diff
git show <commit>

# Undo
git reset
git revert
git restore
```

---

**Document Created:** September 5, 2026  
**Status:** ✅ COMPLETE  
**Next Task:** Task 4 - Software Architecture Diagram

# 🚀 Bluestock Fintech - Mutual Fund Analytics Capstone Project

**Status:** ✅ READY TO START  
**Duration:** 7 Working Days (~50-55 hours)  
**Due Date:** September 10-16, 2026  
**Start Date:** September 1, 2026  

---

## 📌 PROJECT OVERVIEW

Build a **complete end-to-end data engineering pipeline** for the Indian mutual fund industry. This capstone project covers:

✅ **ETL Pipeline** — Ingest & transform 10 real datasets from AMFI India  
✅ **SQL Database** — Design and load a star schema with 5+ tables  
✅ **Exploratory Data Analysis** — 15+ visualizations with key insights  
✅ **Performance Analytics** — Compute Sharpe, Alpha, Beta, VaR, Max Drawdown  
✅ **Interactive Dashboard** — Power BI/Tableau with 4 pages and slicers  
✅ **Advanced Analytics** — Investor cohort analysis, risk metrics, recommendations  
✅ **Final Report** — Professional PDF report + presentation deck  

---

## 📊 DATASETS PROVIDED

| # | File | Rows | Size | Description |
|---|------|------|------|-------------|
| 01 | `fund_master.csv` | 40 | 6.7K | Master list of 40 real mutual fund schemes |
| 02 | `nav_history.csv` | 46K | 1.2M | Daily NAV history for all 40 schemes (2022-2026) |
| 03 | `aum_by_fund_house.csv` | 90 | 4.0K | Quarterly AUM for 10 fund houses |
| 04 | `monthly_sip_inflows.csv` | 48 | 1.7K | Monthly SIP inflows & statistics |
| 05 | `category_inflows.csv` | 144 | 3.6K | Net inflows by fund category |
| 06 | `industry_folio_count.csv` | 21 | 821B | Total mutual fund folios by type |
| 07 | `scheme_performance.csv` | 40 | 6.5K | 1yr/3yr/5yr returns, Sharpe, Alpha, Beta |
| 08 | `investor_transactions.csv` | 32K | 3.0M | SIP/Lumpsum/Redemption transactions (5K investors) |
| 09 | `portfolio_holdings.csv` | 320 | 24K | Top equity holdings & sectors per fund |
| 10 | `benchmark_indices.csv` | 8K | 246K | Daily Nifty 50, 100, MidCap, SmallCap indices |

**Total Data:** 4.5 MB | **Total Rows:** 87K+  
**Data Period:** Jan 2022 - Dec 2025 (Real AMFI data)

---

## 🗂️ FOLDER STRUCTURE

```
BLUESTOCK_CAPSTONE/
│
├── data/                          ← ALL DATASETS
│   ├── raw/                       ← Original CSV files (10 files)
│   ├── processed/                 ← Cleaned & merged CSVs (output)
│   └── db/                        ← SQLite database (bluestock_mf.db)
│
├── notebooks/                     ← JUPYTER NOTEBOOKS (5 files)
│   ├── 01_Data_Ingestion.ipynb
│   ├── 02_Data_Cleaning.ipynb
│   ├── 03_EDA_Analysis.ipynb
│   ├── 04_Performance_Analytics.ipynb
│   └── 05_Advanced_Analytics.ipynb
│
├── scripts/                       ← PYTHON SCRIPTS
│   ├── etl_pipeline.py            ← Master ETL script
│   ├── live_nav_fetch.py          ← Fetch live NAV from API
│   ├── compute_metrics.py         ← Calculate Sharpe, Alpha, Beta
│   ├── recommender.py             ← Fund recommendation engine
│   └── requirements.txt           ← Dependencies
│
├── sql/                           ← SQL FILES
│   ├── schema.sql                 ← CREATE TABLE statements
│   └── queries.sql                ← 10+ analytical queries
│
├── dashboard/                     ← POWER BI / TABLEAU
│   └── bluestock_mf.pbix          ← Interactive dashboard
│
├── reports/                       ← FINAL DELIVERABLES
│   ├── Final_Report.pdf           ← 15-20 page PDF report
│   ├── Presentation.pptx          ← 12-slide presentation
│   └── Dashboard_Screenshots/     ← 4 PNG files
│
└── docs/                          ← DOCUMENTATION
    ├── DAY_1_GUIDE.md             ← Day 1 detailed tasks
    ├── DAY_2_GUIDE.md             ← Day 2 detailed tasks
    ├── ... (Days 3-7)
    └── DATA_DICTIONARY.md         ← Column descriptions
```

---

## 📅 7-DAY TASK BREAKDOWN

### **DAY 1: Data Ingestion (6-8 hours)**
**Goal:** Load all datasets and fetch live NAV data

- [x] Set up project folder structure
- [x] Install dependencies (pandas, numpy, matplotlib, etc.)
- [x] Load all 10 CSV files → validate shapes/dtypes
- [x] Fetch live NAV from mfapi.in API (5 key schemes)
- [x] Create data quality report
- [x] Git commit: "Day 1: Data ingestion complete"

**Deliverables:** `data_ingestion.py`, `requirements.txt`, GitHub repo

---

### **DAY 2: Data Cleaning & Database (7-8 hours)**
**Goal:** Clean data and build SQL database

- [x] Clean all 10 datasets (handle nulls, duplicates, types)
- [x] Design 5-table star schema in SQLite
- [x] Load cleaned data into database
- [x] Write and test 10 SQL queries
- [x] Create data dictionary

**Deliverables:** `bluestock_mf.db`, `schema.sql`, `queries.sql`

---

### **DAY 3: EDA & Visualizations (7-8 hours)**
**Goal:** Explore data and create 15+ charts

- [x] NAV trend analysis (40 schemes, 2022-2026)
- [x] AUM growth by fund house (bar charts)
- [x] SIP inflow time-series with milestones
- [x] Category inflow heatmap
- [x] Investor demographics (age, gender, state)
- [x] Geographic distribution (T30 vs B30)
- [x] Correlation matrix of fund returns
- [x] Sector allocation donuts
- [x] Document 10 key insights

**Deliverables:** `03_EDA_Analysis.ipynb`, 15+ PNG charts

---

### **DAY 4: Performance Analytics (7-8 hours)**
**Goal:** Compute all financial metrics

- [x] Daily returns (daily_return = nav_t / nav_t-1 - 1)
- [x] CAGR (1yr, 3yr, 5yr) for all 40 funds
- [x] Sharpe Ratio (Rp - Rf) / Std(Rp) × √252
- [x] Sortino Ratio (downside deviation only)
- [x] Alpha & Beta (OLS regression vs Nifty 100)
- [x] Maximum Drawdown analysis
- [x] Fund Scorecard (0-100 composite score)
- [x] Benchmark comparison chart

**Deliverables:** `04_Performance_Analytics.ipynb`, `fund_scorecard.csv`, `alpha_beta.csv`

---

### **DAY 5: Dashboard Development (7-8 hours)**
**Goal:** Build interactive Power BI dashboard

- [x] PAGE 1: Industry Overview (KPIs, AUM trend, AMC bar chart)
- [x] PAGE 2: Fund Performance (scatter plot, scorecard, NAV vs benchmark)
- [x] PAGE 3: Investor Analytics (state map, age distribution, transaction volume)
- [x] PAGE 4: SIP & Market Trends (dual-axis, category heatmap)
- [x] Add slicers, drill-through, tooltips
- [x] Apply Bluestock branding & color scheme
- [x] Export to PDF + PNG screenshots

**Deliverables:** `bluestock_mf.pbix`, `Dashboard.pdf`, 4 PNG files

---

### **DAY 6: Advanced Analytics (6-7 hours)**
**Goal:** Deep-dive analytics and risk metrics

- [x] Historical VaR (95%) & CVaR for all 40 funds
- [x] Rolling 90-day Sharpe Ratio (plot for 5 funds)
- [x] Investor cohort analysis (by first transaction year)
- [x] SIP continuity analysis (flag at-risk investors)
- [x] Simple fund recommender (Low/Moderate/High risk)
- [x] Sector concentration HHI analysis
- [x] Write 5 advanced insights

**Deliverables:** `05_Advanced_Analytics.ipynb`, `var_cvar_report.csv`, `recommender.py`

---

### **DAY 7: Final Report & Presentation (6-7 hours)**
**Goal:** Document and present complete project

- [x] Write Final Report (15-20 pages PDF)
  - Executive Summary
  - Data & ETL Architecture
  - EDA Findings
  - Performance Analysis
  - Dashboard Screenshots
  - Key Recommendations
  - Limitations & Future Work

- [x] Create 12-slide presentation
- [x] Clean all Python code (docstrings, no debug prints)
- [x] Write comprehensive README.md
- [x] Final GitHub commit + tag v1.0
- [x] (Optional) Publish dashboard to Power BI Service / Tableau Public

**Deliverables:** `Final_Report.pdf`, `Presentation.pptx`, GitHub repo with README

---

## 🔧 QUICK START

### 1. **Install Dependencies**
```bash
pip install -r scripts/requirements.txt
```

### 2. **Run Day 1 (Data Ingestion)**
```bash
python scripts/etl_pipeline.py
# Output: All datasets loaded to data/processed/
```

### 3. **Run Day 2 (SQL Database)**
```bash
sqlite3 data/db/bluestock_mf.db < sql/schema.sql
python -c "
import sqlite3
import pandas as pd

# Load cleaned data into DB
conn = sqlite3.connect('data/db/bluestock_mf.db')
# (detailed loading in Day 2 notebook)
"
```

### 4. **Run Day 3 (EDA)**
```bash
jupyter notebook notebooks/03_EDA_Analysis.ipynb
```

### 5. **Open Dashboard**
```bash
# Open with Power BI Desktop:
open dashboard/bluestock_mf.pbix
```

---

## 📋 SUBMISSION CHECKLIST

### Week 1: Learning + Capstone Start
- [ ] All 5 Jupyter notebooks completed
- [ ] All Python scripts working without errors
- [ ] SQLite database loaded with clean data
- [ ] EDA Analysis notebook with 15+ charts
- [ ] 10 SQL queries tested and documented

### Week 2: Capstone Final Submission
- [ ] Final Report PDF (15-20 pages)
- [ ] Presentation PowerPoint (12 slides)
- [ ] Interactive Dashboard (4 pages with slicers)
- [ ] Performance Metrics (all formulas correct)
- [ ] Advanced Analytics (VaR, recommendations)
- [ ] Clean GitHub repo with README + v1.0 tag
- [ ] Daily standup form completed (Mon-Fri)

---

## 🎯 KEY SUCCESS FACTORS

✅ **Start immediately on Day 1** — Don't delay data ingestion  
✅ **Test SQL queries early** — Run queries on Day 2, don't wait until Day 4  
✅ **Create charts as you go** — EDA is iterative, not a separate task  
✅ **Validate numbers constantly** — Verify CAGR, Sharpe, Alpha formulas  
✅ **Document findings** — Write insights alongside each chart  
✅ **Use real fund names** — Reference actual schemes in your presentation  
✅ **Show domain knowledge** — Explain what Sharpe ratio means in your report  

---

## ⚠️ COMMON MISTAKES TO AVOID

❌ **Hard-coding file paths** → Use `pathlib.Path` or `os.path.join`  
❌ **Not handling weekends in NAV** → Always `ffill()` after reindexing  
❌ **Using calendar days for CAGR** → Annualise with `252 / n_trading_days`  
❌ **Dashboard with no slicers** → Every page needs 2+ interactive filters  
❌ **Confusing AUM units** → Always specify: `aum_lakh_crore` vs `aum_crore`  
❌ **Hardcoding formulas** → Use parametric calculations, not copy-paste  
❌ **Late Git commits** → Commit daily, don't push everything on Day 7  

---

## 📞 SUPPORT & RESOURCES

**Project Manager:** Yash Kale (yashkale@bluestock.in)  
**Daily Standup Form:** Complete Mon-Fri (part of evaluation)  
**Office Hours:** Ask your PM for blockers, don't struggle in silence  

**Learning Resources:**
- **AMFI Data:** www.amfiindia.com (official fund data)
- **NAV API:** api.mfapi.in/mf/{amfi_code}
- **Zerodha Varsity:** zerodha.com/varsity (free MF education)
- **Alex the Analyst (SQL):** youtube.com/@alextheanalyst
- **Krish Naik (ML):** youtube.com/@krishnaik06

---

## ✨ BONUS CHALLENGES (+10 marks each)

**B1** — Schedule ETL as cron job (auto-fetch NAV every weekday 8 PM)  
**B2** — Build Streamlit web app as Power BI alternative  
**B3** — Monte Carlo simulation (5-year NAV projections)  
**B4** — Markowitz Efficient Frontier (portfolio optimization)  
**B5** — Automated HTML email reports (weekly summaries)  

---

## 📊 EVALUATION RUBRIC

| Deliverable | Format | Weight | Criteria |
|---|---|---|---|
| **D1** ETL Pipeline | `.py` | 15% | Runs without manual steps, error handling |
| **D2** SQL Database | `.db` + `.sql` | 10% | Correct schema, all data loaded |
| **D3** EDA Notebook | `.ipynb` | 15% | 15+ charts, depth of analysis, insights |
| **D4** Performance Metrics | `.ipynb` + `.csv` | 15% | Mathematical accuracy, correct formulas |
| **D5** Interactive Dashboard | `.pbix` or `.twbx` | 20% | Design quality, all 4 pages, slicers work |
| **D6** Advanced Analytics | `.ipynb` | 10% | VaR correct, cohort analysis, recommender |
| **D7** Final Report + Slides | `.pdf` + `.pptx` | 15% | Professional quality, completeness |

---

## 🚀 LET'S GO!

You have everything you need:
- ✅ 10 real datasets ready to load
- ✅ Detailed task breakdown for each day
- ✅ Project folder structure set up
- ✅ Day-by-day guides (see `docs/` folder)
- ✅ Python script templates
- ✅ SQL schema template

**NOW IT'S YOUR TURN!**

Start with **Day 1**: Open `notebooks/01_Data_Ingestion.ipynb` and begin loading the datasets.

---

**Last Updated:** September 5, 2026  
**Project Status:** ✅ READY TO LAUNCH  
**Good luck! 🎓**

---

*"Data is the new oil. Your mission is to refine it into insights."*  
— Bluestock Fintech Analytics Team

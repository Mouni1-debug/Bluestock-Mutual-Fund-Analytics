# 📅 DAY 1: DATA INGESTION & PROJECT SETUP

**Duration:** 6-8 hours  
**Objective:** Load all 10 datasets, fetch live NAV, validate data quality  
**Deliverables:** `data_ingestion.py`, `live_nav_fetch.py`, `requirements.txt`, GitHub repo

---

## 🎯 TASK OVERVIEW

| Task # | Task Name | Duration | Output |
|--------|-----------|----------|--------|
| 1 | Setup project folder + Git | 30m | Folder structure + GitHub repo |
| 2 | Install dependencies | 20m | `requirements.txt` |
| 3 | Load all 10 CSV datasets | 60m | `data_ingestion.py` |
| 4 | Explore data with Pandas | 45m | Notebook output (shape, dtypes, head) |
| 5 | Fetch live NAV from API | 60m | `live_nav_fetch.py` |
| 6 | Fetch NAV for 5 key schemes | 60m | 5 raw NAV CSV files |
| 7 | Understand fund master | 30m | Jupyter notebook output |
| 8 | Validate AMFI codes | 20m | Data quality report |
| 9 | Git commit | 10m | Remote repo updated |

---

## 📝 DETAILED TASKS

### **TASK 1: Setup Project Folder + Git (30 minutes)**

**What to do:**
1. Create the folder structure (already done for you)
2. Initialize Git repository
3. Create `.gitignore` file
4. Make first commit

**Code to run:**
```bash
cd ~/bluestock_capstone/

# Initialize Git
git init
git remote add origin https://github.com/YOUR_USERNAME/bluestock-mf-capstone.git

# Create .gitignore
cat > .gitignore << EOF
*.db
*.pyc
__pycache__/
.ipynb_checkpoints/
*.ipynb_checkpoints
.DS_Store
*.xlsx
*.tmp
venv/
.venv/
EOF

# First commit
git add .
git commit -m "Day 1 Start: Project initialized"
git branch -M main
git push -u origin main
```

**Output:** GitHub repository created with initial commit

---

### **TASK 2: Install Dependencies (20 minutes)**

**Create `scripts/requirements.txt`:**
```
pandas==2.0.3
numpy==1.24.3
matplotlib==3.7.1
seaborn==0.12.2
plotly==5.14.1
jupyter==1.0.0
jupyterlab==4.0.0
sqlalchemy==2.0.19
sqlite3
requests==2.31.0
scipy==1.11.1
openpyxl==3.1.2
python-dateutil==2.8.2
```

**Run installation:**
```bash
pip install -r scripts/requirements.txt
```

**Verify installation:**
```python
python -c "import pandas; import numpy; import matplotlib; print('✅ All dependencies installed')"
```

---

### **TASK 3: Load All 10 CSV Datasets (60 minutes)**

**Create `scripts/etl_pipeline.py`:**

```python
#!/usr/bin/env python3
"""
ETL Pipeline - Day 1
Load all 10 datasets from raw folder
"""

import pandas as pd
import numpy as np
from pathlib import Path
import sys

# Define paths
BASE_DIR = Path(__file__).parent.parent
RAW_DATA_DIR = BASE_DIR / "data/raw"
PROCESSED_DATA_DIR = BASE_DIR / "data/processed"

# Create processed folder if not exists
PROCESSED_DATA_DIR.mkdir(exist_ok=True)

print("=" * 80)
print("BLUESTOCK FINTECH - DAY 1: DATA INGESTION")
print("=" * 80)
print()

# Dictionary of datasets
datasets = {
    "01_fund_master": "40 mutual fund schemes with metadata",
    "02_nav_history": "Daily NAV for all 40 schemes (2022-2026)",
    "03_aum_by_fund_house": "Quarterly AUM by fund house",
    "04_monthly_sip_inflows": "Monthly SIP inflow statistics",
    "05_category_inflows": "Category-wise net inflows",
    "06_industry_folio_count": "Total industry folios by type",
    "07_scheme_performance": "1yr/3yr/5yr returns and metrics",
    "08_investor_transactions": "SIP, Lumpsum, Redemption transactions",
    "09_portfolio_holdings": "Equity holdings and sectors",
    "10_benchmark_indices": "Nifty 50, 100, MidCap indices"
}

loaded_data = {}

print("[STEP 1] LOADING ALL 10 DATASETS")
print("-" * 80)

for file_key, description in datasets.items():
    file_path = RAW_DATA_DIR / f"{file_key}.csv"
    
    try:
        df = pd.read_csv(file_path)
        loaded_data[file_key] = df
        
        print(f"✅ {file_key}")
        print(f"   Description: {description}")
        print(f"   Shape: {df.shape[0]} rows × {df.shape[1]} columns")
        print(f"   Size: {df.memory_usage(deep=True).sum() / 1024:.2f} KB")
        print()
        
    except FileNotFoundError:
        print(f"❌ ERROR: {file_key}.csv not found!")
        sys.exit(1)
    except Exception as e:
        print(f"❌ ERROR loading {file_key}: {str(e)}")
        sys.exit(1)

print()
print("[STEP 2] DATA QUALITY ASSESSMENT")
print("-" * 80)

for file_key, df in loaded_data.items():
    missing_pct = (df.isnull().sum().sum() / (df.shape[0] * df.shape[1])) * 100
    duplicates = df.duplicated().sum()
    
    print(f"{file_key}:")
    print(f"  Missing values: {df.isnull().sum().sum()} ({missing_pct:.2f}%)")
    print(f"  Duplicates: {duplicates}")
    print(f"  Data types: {df.dtypes.to_dict()}")
    print()

print()
print("[STEP 3] DATASET EXPLORATION")
print("-" * 80)

# Fund Master
print("FUND MASTER (01):")
print(f"  Unique fund houses: {loaded_data['01_fund_master']['fund_house'].nunique()}")
print(f"  Categories: {loaded_data['01_fund_master']['category'].unique()}")
print(f"  Date range in AMFI codes: {loaded_data['01_fund_master'].shape[0]} schemes")
print()

# NAV History
nav_df = loaded_data['02_nav_history']
print("NAV HISTORY (02):")
print(f"  Date range: {nav_df['date'].min()} to {nav_df['date'].max()}")
print(f"  Unique schemes: {nav_df['amfi_code'].nunique()}")
print(f"  Trading days: {nav_df.shape[0]}")
print()

# AUM by Fund House
aum_df = loaded_data['03_aum_by_fund_house']
print("AUM BY FUND HOUSE (03):")
if 'aum_crore' in aum_df.columns or 'aum' in aum_df.columns:
    aum_col = 'aum_crore' if 'aum_crore' in aum_df.columns else 'aum'
    print(f"  Max AUM: Rs. {aum_df[aum_col].max():,.0f} Cr")
    print(f"  Total records: {aum_df.shape[0]}")
print()

# Investor Transactions
txn_df = loaded_data['08_investor_transactions']
print("INVESTOR TRANSACTIONS (08):")
print(f"  Unique investors: {txn_df['investor_id'].nunique()}")
print(f"  Date range: {txn_df['transaction_date'].min()} to {txn_df['transaction_date'].max()}")
print(f"  Total transactions: {txn_df.shape[0]}")
print()

print()
print("[STEP 4] SAVING CLEANED DATA")
print("-" * 80)

for file_key, df in loaded_data.items():
    # Save to processed folder
    output_file = PROCESSED_DATA_DIR / f"{file_key}_cleaned.csv"
    df.to_csv(output_file, index=False)
    print(f"✅ Saved: {file_key}_cleaned.csv")

print()
print("=" * 80)
print("✅ DAY 1: DATA INGESTION COMPLETE!")
print("=" * 80)
print(f"\nAll datasets loaded and saved to: {PROCESSED_DATA_DIR}")
```

**Run the script:**
```bash
python scripts/etl_pipeline.py
```

**Expected Output:**
```
================================================================================
BLUESTOCK FINTECH - DAY 1: DATA INGESTION
================================================================================

[STEP 1] LOADING ALL 10 DATASETS
...
✅ All 10 datasets loaded successfully
Total data size: 4.5 MB
```

---

### **TASK 4: Explore Data with Pandas (45 minutes)**

**Create `notebooks/01_Data_Ingestion.ipynb`** with cells:

```python
# Cell 1: Imports
import pandas as pd
import numpy as np
from pathlib import Path

# Cell 2: Load data
BASE_DIR = Path.cwd()
RAW_DATA_DIR = BASE_DIR / "data/raw"

fund_master = pd.read_csv(RAW_DATA_DIR / "01_fund_master.csv")
nav_history = pd.read_csv(RAW_DATA_DIR / "02_nav_history.csv")
transactions = pd.read_csv(RAW_DATA_DIR / "08_investor_transactions.csv")

# Cell 3: Fund Master exploration
print("FUND MASTER")
print(fund_master.shape)
print(fund_master.head())
print(fund_master.dtypes)
print(fund_master.describe())

# Cell 4: NAV History exploration
print("\nNAV HISTORY")
print(nav_history.shape)
print(nav_history.head())
print(nav_history['date'].min(), "to", nav_history['date'].max())

# Cell 5: Missing values
for file_key in ["fund_master", "nav_history", "transactions"]:
    df = eval(file_key)
    print(f"\n{file_key} - Missing values:")
    print(df.isnull().sum())
```

---

### **TASK 5: Fetch Live NAV from API (60 minutes)**

**Create `scripts/live_nav_fetch.py`:**

```python
#!/usr/bin/env python3
"""
Fetch live NAV data from mfapi.in
Real-time data for real fund schemes
"""

import requests
import pandas as pd
import json
from datetime import datetime
from pathlib import Path

# Define paths
BASE_DIR = Path(__file__).parent.parent
RAW_DATA_DIR = BASE_DIR / "data/raw"

# List of major funds to fetch (AMFI codes)
MAJOR_FUNDS = {
    "125497": "HDFC Top 100 Direct",
    "119551": "SBI Bluechip Direct",
    "120503": "ICICI Bluechip Direct",
    "118632": "Nippon Large Cap Direct",
    "119092": "Axis Bluechip Direct"
}

API_BASE = "https://api.mfapi.in/mf"

print("=" * 80)
print("FETCHING LIVE NAV FROM mfapi.in")
print("=" * 80)
print()

for amfi_code, fund_name in MAJOR_FUNDS.items():
    print(f"Fetching {fund_name} (Code: {amfi_code})...")
    
    try:
        url = f"{API_BASE}/{amfi_code}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        
        # Extract relevant info
        meta = data['meta']
        nav_data = data['data']
        
        print(f"  ✅ Fund Name: {meta['fund_name']}")
        print(f"  Latest NAV: Rs. {nav_data[0]['nav']} (as of {nav_data[0]['date']})")
        print(f"  Total records: {len(nav_data)}")
        
        # Save to CSV
        nav_df = pd.DataFrame(nav_data)
        nav_df['amfi_code'] = amfi_code
        nav_df['fund_name'] = meta['fund_name']
        
        output_file = RAW_DATA_DIR / f"live_nav_{amfi_code}.csv"
        nav_df.to_csv(output_file, index=False)
        print(f"  💾 Saved: {output_file.name}")
        print()
        
    except requests.exceptions.RequestException as e:
        print(f"  ❌ Error: {str(e)}")
        print()
    except Exception as e:
        print(f"  ❌ Unexpected error: {str(e)}")
        print()

print("=" * 80)
print("✅ NAV FETCHING COMPLETE!")
print("=" * 80)
```

**Run it:**
```bash
python scripts/live_nav_fetch.py
```

---

### **TASK 6: Fetch NAV for 5 Key Schemes (60 minutes)**

**Done in Task 5** — Script fetches all 5 schemes automatically

---

### **TASK 7: Understand Fund Master (30 minutes)**

**Add this to Jupyter notebook:**

```python
# Explore fund master
fund_master = pd.read_csv("data/raw/01_fund_master.csv")

print("UNIQUE FUND HOUSES:")
print(fund_master['fund_house'].unique())
print(f"Total: {fund_master['fund_house'].nunique()}")

print("\nCATEGORIES:")
print(fund_master['category'].unique())

print("\nSUB-CATEGORIES:")
print(fund_master['sub_category'].unique())

print("\nRISK GRADES:")
print(fund_master['risk_grade'].unique())

print("\nEXPENSE RATIOS:")
print(f"Min: {fund_master['expense_ratio_pct'].min():.2f}%")
print(f"Max: {fund_master['expense_ratio_pct'].max():.2f}%")
print(f"Avg: {fund_master['expense_ratio_pct'].mean():.2f}%")
```

---

### **TASK 8: Validate AMFI Codes (20 minutes)**

```python
# Validate AMFI codes
fund_master = pd.read_csv("data/raw/01_fund_master.csv")
nav_history = pd.read_csv("data/raw/02_nav_history.csv")

print("DATA QUALITY REPORT")
print("=" * 80)

# Check missing codes
missing_codes = set(fund_master['amfi_code']) - set(nav_history['amfi_code'])
if missing_codes:
    print(f"⚠️  Missing from NAV history: {missing_codes}")
else:
    print("✅ All fund master codes present in NAV history")

# Check extra codes
extra_codes = set(nav_history['amfi_code']) - set(fund_master['amfi_code'])
if extra_codes:
    print(f"⚠️  Extra codes in NAV history: {extra_codes}")
else:
    print("✅ No extra codes in NAV history")

# Date validation
print(f"\nNAV History date range: {nav_history['date'].min()} to {nav_history['date'].max()}")
print(f"Trading days: {nav_history.shape[0]}")
```

---

### **TASK 9: Git Commit (10 minutes)**

```bash
git add .
git commit -m "Day 1: Data ingestion & exploration complete
- Loaded all 10 CSV datasets
- Fetched live NAV from mfapi.in
- Created data quality report
- Validated AMFI codes"
git push origin main
```

---

## ✅ DAY 1 CHECKLIST

- [ ] Project folder structure created
- [ ] Git repository initialized and first commit made
- [ ] `requirements.txt` created with all dependencies
- [ ] All 10 CSV datasets loaded successfully
- [ ] `data_ingestion.py` script working without errors
- [ ] Live NAV fetched from 5 major schemes
- [ ] Data exploration completed in Jupyter notebook
- [ ] Data quality report generated
- [ ] AMFI codes validated
- [ ] Daily standup form completed
- [ ] Code committed with meaningful message

---

## 🎯 DAY 1 DELIVERABLES

```
✅ scripts/etl_pipeline.py          ← Main data loading script
✅ scripts/live_nav_fetch.py        ← API data fetching
✅ scripts/requirements.txt         ← Dependencies
✅ notebooks/01_Data_Ingestion.ipynb ← Exploration notebook
✅ .gitignore                       ← Git configuration
✅ GitHub repo                      ← First commit pushed
✅ data/processed/                  ← Cleaned CSVs (10 files)
```

---

## 📊 EXPECTED OUTPUTS

**Loaded datasets summary:**
- 01_fund_master: 40 rows (fund schemes)
- 02_nav_history: 46,000+ rows (NAV daily)
- 03_aum_by_fund_house: 90 rows (quarterly AUM)
- 04_monthly_sip_inflows: 48 rows (SIP monthly)
- 05_category_inflows: 144+ rows (category flows)
- 06_industry_folio_count: 21 rows (industry folios)
- 07_scheme_performance: 40 rows (1yr/3yr/5yr returns)
- 08_investor_transactions: 32,000+ rows (transactions)
- 09_portfolio_holdings: 320 rows (equity holdings)
- 10_benchmark_indices: 8,000+ rows (index daily)

**Total data:** 4.5 MB | **Total rows:** 87,000+

---

## 🚀 NEXT STEPS

Once Day 1 is complete:
→ Move on to **DAY 2: Data Cleaning & SQL Database**
→ See `DAY_2_GUIDE.md`

---

**Duration spent:** Track your hours  
**Issues encountered:** Document them  
**Key learnings:** Note them down  
**Ready for Day 2?** ✅ YES / ❌ NO

---

Good luck! 🎓
